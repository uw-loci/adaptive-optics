#include <condefs.h>



USEUNIT("SpotExample.c");
USERC("SpotExample.rc");


#define WinMain


