/*******************************************************************
This is a simple example application in C which demonstrates some of
the basic functionality of the SpotCam driver.

Copyright 2004-2008, Diagnostic Instruments, Inc.
*******************************************************************/

#define STRICT

#include <stdio.h>
#include <windows.h>
#pragma hdrstop
#include <windowsx.h>

#include "SpotCam.h"
#include "SpotExample.h"


// To use SpotWaitForStatusChange (polling mode) instead of a callback, uncomment-out the next line
#define USE_SPOTWAITFORSTATUSCHANGE


typedef struct
{
   char szModelNumber[11], szSerialNumber[21], szRevisionNumber[11];
   int  nMaxImageWidth, nMaxImageHeight, nMinImageWidth, nMinImageHeight;
   int  nMosaicPattern, nMaxPixelResolutionLevel, nNumReadoutCircuits, nNumGainPorts0;
   BOOL bCanDoColor, bHasMosaicSensor, bDoesMultiShotColor, bHasFilterWheel;
   BOOL bHasSlider, bCanDetectSliderPosition, bCanComputeExposure;
   BOOL bCanDoEdgeTrigger, bCanDoBulbTrigger, bCanSetTriggerActiveState;
   BOOL bCanReadSensorTemperature, bCanRegulateSensorTemperature;
   BOOL bCanDoAccurateTTLOutputAndTriggerDelayTiming;
   BOOL bCanDoLiveMode, bCanShiftImageSensor, bCanDoLiveImageScaling;
   BOOL bIs1394FireWireCamera;
} CAMERA_INFORMATION_STRUCT;


HINSTANCE hInstance;
char  szWindowClassName[] =  "SpotCamExample";
char  szAppName[] =          "SpotCam Example";
HWND  hMainWindow, hStatusDlg;
int   nNumCameras;
short nSelCameraIndex=-1;
BOOL  bAbortFlag, bBusy=FALSE;
int   nImageWidth, nImageHeight, nImageBitDepth;
BITMAPINFOHEADER *pstBitmapInfo=NULL;
BYTE  *pbyPixelData=NULL;
HGLOBAL hImageBuffer=NULL;
RECT  stImageDisplayRect;
CAMERA_INFORMATION_STRUCT stCameraInfo;
HINSTANCE hSpotCamDLL;


// typedefs for API functions
typedef int (WINAPI *SPOTSETVALUE)(short nParam, void *pValue);
typedef int (WINAPI *SPOTGETVALUE)(short nParam, void *pValue);
typedef int (WINAPI *SPOTGETCAMERAATTRIBUTES)(DWORD *pdwAttributes);
typedef void (WINAPI *SPOTGETVERSIONINFO2)(SPOT_VERSION_STRUCT2 *pstVerInfo);
typedef int (WINAPI *SPOTCOMPUTEEXPOSURE2)(SPOT_EXPOSURE_STRUCT2 *pstExposure);
typedef int (WINAPI *SPOTCOMPUTEWHITEBALANCE)(SPOT_WHITE_BAL_STRUCT *pstWhiteBal);
typedef int (WINAPI *SPOTGETIMAGE)(short nBPP, BOOL bQuickPic, short nSkipLines, void *pImageBuffer,
                                   long *plRedPixelCnts, long *plGreenPixelCnts, long *plBluePixelCnts);
typedef int (WINAPI *SPOTGETSEQUENTIALIMAGES)(int nNumImages, int nIntervalMSec, BOOL bAutoExposeOnEach,
                                              BOOL bUseTriggerOnEach, BOOL bDeferProcessing, void **ppImageBuffers);
typedef int (WINAPI *SPOTGETLIVEIMAGES)(BOOL bComputeExposure, short nFilterColor, short nRotateDirection,
                                        BOOL bFlipHoriz, BOOL bFlipVert, void *pImageBuffer);
typedef int (WINAPI *SPOTRETRIEVESEQUENTIALIMAGE)(void *pImageBuffer);
typedef void (WINAPI *SPOTSETABORTFLAG)(BOOL *pbAbort);
typedef void (WINAPI *SPOTSETCALLBACK)(SPOTCALLBACK pfnCallback, DWORD dwUserData);
typedef void (WINAPI *SPOTSETDEVICENOTIFICATIONCALLBACK)(SPOTDEVNOTIFYCALLBACK pfnCallback, DWORD dwUserData);
typedef void (WINAPI *SPOTCLEARSTATUS)(void);
typedef int (WINAPI *SPOTINIT)(void);
typedef int (WINAPI *SPOTEXIT)(void);
typedef int (WINAPI *SPOTFINDDEVICES)(SPOT_DEVICE_STRUCT *pstDevices, int *pnNumDevices);
typedef int (WINAPI *SPOTGETEXPOSURETIMESTAMP)(SPOT_TIMESTAMP_STRUCT *pstTimestamp);
typedef int (WINAPI *SPOTGETSENSORCURRENTTEMPERATURE)(short *pnTemperature, BOOL *pbIsNewValue);
typedef int (WINAPI *SPOTGETSENSOREXPOSURETEMPERATURE)(short *pnTemperature);
typedef BOOL (WINAPI *SPOTWAITFORSTATUSCHANGE)(int *pnStatus, long *plInfo, int nTimeoutMSec);
typedef int (WINAPI *SPOTGETCAMERAERRORCODE)(void);


SPOTSETVALUE pSpotSetValue;
SPOTGETVALUE pSpotGetValue;
SPOTGETCAMERAATTRIBUTES pSpotGetCameraAttributes;
SPOTGETVERSIONINFO2 pSpotGetVersionInfo2;
SPOTCOMPUTEEXPOSURE2 pSpotComputeExposure2;
SPOTCOMPUTEWHITEBALANCE pSpotComputeWhiteBalance;
SPOTGETIMAGE pSpotGetImage;
SPOTGETLIVEIMAGES pSpotGetLiveImages;
SPOTGETSEQUENTIALIMAGES pSpotGetSequentialImages;
SPOTRETRIEVESEQUENTIALIMAGE pSpotRetrieveSequentialImage;
SPOTSETABORTFLAG pSpotSetAbortFlag;
SPOTSETCALLBACK pSpotSetCallback;
SPOTSETDEVICENOTIFICATIONCALLBACK pSpotSetDeviceNotificationCallback;
SPOTCLEARSTATUS pSpotClearStatus;
SPOTINIT pSpotInit;
SPOTEXIT pSpotExit;
SPOTFINDDEVICES pSpotFindDevices;
SPOTGETEXPOSURETIMESTAMP pSpotGetExposureTimestamp;
SPOTGETSENSORCURRENTTEMPERATURE pSpotGetSensorCurrentTemperature;
SPOTGETSENSOREXPOSURETEMPERATURE pSpotGetSensorExposureTemperature;
SPOTWAITFORSTATUSCHANGE pSpotWaitForStatusChange;
SPOTGETCAMERAERRORCODE pSpotGetCameraErrorCode;



int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int cmdShow);
LRESULT CALLBACK _export MainWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK _export StatusDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void InitializeCamera(void);
void DisplayError(int nErrCode);
void DisplayWarning(int nWarnCode);
void ShutDown(void);
void EvPaint(void);
void DrawImage(HDC hDC);
void ComputeImageDisplayRect(void);
BOOL AllocateImageBuffer(void);
void AcquireImages(BOOL bSequentialAcquisition, BOOL bAcquireUntilAborted);
void RunLiveMode(void);
void GetWhiteBalance(void);
void ReadTemperature(void);
void WINAPI OurCallbackFunc(int iStatus, long lInfo, DWORD dwUserData);
int  WaitForOperationToFinish(void);
BOOL LoadSpotCamDLL(void);



void InitializeCamera()
{
   int nRetVal;
   DWORD dwAttributes;
   SPOT_VERSION_STRUCT2 stVerInfo;
   short asTemp[100];
   HMENU hMenu;
   BOOL bTemp;

   // Tell the SpotCam driver to use the camera that the user selected
   (*pSpotSetValue)(SPOT_DRIVERDEVICENUMBER, &nSelCameraIndex);
   bAbortFlag = FALSE;
   nRetVal = (*pSpotInit)();
   if (nRetVal < 0) DisplayWarning(nRetVal);
   else if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      nSelCameraIndex = -1;
      return;
   }
   // Check the menu item for this camera
   hMenu = GetMenu(hMainWindow);
   hMenu = GetSubMenu(hMenu, 0);
   CheckMenuItem(hMenu, CM_FIRSTCAMERA + nSelCameraIndex, MF_BYCOMMAND|MF_CHECKED);

   (*pSpotSetAbortFlag)(&bAbortFlag);  
   // Create status notification dialog
   hStatusDlg = CreateDialog(hInstance, "StatusDlg", hMainWindow, StatusDlgProc);
   // Get information about the camera
   (*pSpotGetCameraAttributes)(&dwAttributes);
   stCameraInfo.bCanDoColor = dwAttributes & SPOT_ATTR_COLOR;
   stCameraInfo.bHasMosaicSensor = dwAttributes & SPOT_ATTR_MOSAIC;
   stCameraInfo.bDoesMultiShotColor = dwAttributes & SPOT_ATTR_COLORFILTER;
   stCameraInfo.bHasFilterWheel = dwAttributes & SPOT_ATTR_FILTERWHEEL;
   stCameraInfo.bHasSlider = dwAttributes & SPOT_ATTR_SLIDER;
   stCameraInfo.bCanDetectSliderPosition = dwAttributes & SPOT_ATTR_SLIDERPOSITIONDETECTION;
   stCameraInfo.bCanComputeExposure = dwAttributes & SPOT_ATTR_AUTOEXPOSURE;
   stCameraInfo.bCanDoEdgeTrigger = dwAttributes & SPOT_ATTR_EDGETRIGGER;
   stCameraInfo.bCanDoBulbTrigger = dwAttributes & SPOT_ATTR_BULBTRIGGER;
   stCameraInfo.bCanSetTriggerActiveState = dwAttributes & SPOT_ATTR_TRIGGERACTIVESTATE;
   stCameraInfo.bCanReadSensorTemperature = dwAttributes & SPOT_ATTR_TEMPERATUREREADOUT;
   stCameraInfo.bCanRegulateSensorTemperature = dwAttributes & SPOT_ATTR_TEMPERATUREREGULATION;
   stCameraInfo.bCanDoAccurateTTLOutputAndTriggerDelayTiming = dwAttributes & SPOT_ATTR_ACCURATETTLDELAYTIMING;
   stCameraInfo.bCanDoLiveMode = dwAttributes & SPOT_ATTR_LIVEMODE;
   stCameraInfo.bCanShiftImageSensor = dwAttributes & SPOT_ATTR_SENSORSHIFTING;
   stCameraInfo.bIs1394FireWireCamera = dwAttributes & SPOT_ATTR_1394;
   stCameraInfo.bCanDoLiveImageScaling = dwAttributes & SPOT_ATTR_LIVEHISTOGRAM;
   (*pSpotGetVersionInfo2)(&stVerInfo);
   strcpy(stCameraInfo.szModelNumber, stVerInfo.szCameraModelNum);
   strcpy(stCameraInfo.szSerialNumber, stVerInfo.szCameraSerialNum);
   strcpy(stCameraInfo.szRevisionNumber, stVerInfo.szCameraRevNum);
   // Determine the min and max allowable acquisition area sizes
   if ((*pSpotGetValue)(SPOT_MAXIMAGERECTSIZE, asTemp) == SPOT_SUCCESS)
   {
      stCameraInfo.nMaxImageWidth = asTemp[0];
      stCameraInfo.nMaxImageHeight = asTemp[1];
   }
   if ((*pSpotGetValue)(SPOT_MINIMAGERECTSIZE, asTemp) == SPOT_SUCCESS)
   {
      stCameraInfo.nMinImageWidth = asTemp[0];
      stCameraInfo.nMinImageHeight = asTemp[1];
   }
   if ((*pSpotGetValue)(SPOT_MAXPIXELRESOLUTIONLEVEL, asTemp) == SPOT_SUCCESS)
      stCameraInfo.nMaxPixelResolutionLevel = asTemp[0];
   if (stCameraInfo.bHasMosaicSensor && ((*pSpotGetValue)(SPOT_MOSAICPATTERN, asTemp) == SPOT_SUCCESS))
      stCameraInfo.nMosaicPattern = asTemp[0];
   // Find out how many readout circuits this camera has
   if ((*pSpotGetValue)(SPOT_NUMBERREADOUTCIRCUITS, asTemp) == SPOT_SUCCESS) stCameraInfo.nNumReadoutCircuits = asTemp[0];
   // Use readout circuit 0
   asTemp[0] = 0;
   (*pSpotSetValue)(SPOT_READOUTCIRCUIT, asTemp);
   // Find out how many gain ports are available for readout circuit 0
   if ((*pSpotGetValue)(SPOT_MAXGAINPORTNUMBER, asTemp) == SPOT_SUCCESS) stCameraInfo.nNumGainPorts0 = asTemp[0] + 1;
   if (stCameraInfo.nNumGainPorts0 >= 2)
   { // Use gain port 1 if it provides the same type of gain as port 0, but as a continuous range
      if (((*pSpotGetValue)(SPOT_PORT1GAINATTRIBUTES, &dwAttributes) == SPOT_SUCCESS) && (dwAttributes & SPOT_GAINATTR_SAMEASPORT0))
      {
         asTemp[0] = (short)1;
         (*pSpotSetValue)(SPOT_GAINPORTNUMBER, asTemp);
      }
   }
   // Get the rest of the camera's values ...

#ifdef USE_SPOTWAITFORSTATUSCHANGE
   bTemp = TRUE;
   (*pSpotSetValue)(SPOT_WAITFORSTATUSCHANGES, &bTemp);  // Enable polling mode
#else
   // Register our callback function
   (*pSpotSetCallback)(OurCallbackFunc, 0);
#endif // USE_SPOTWAITFORSTATUSCHANGE

   // Enable some menu items based on the camera characteristics
   hMenu = GetMenu(hMainWindow);
   hMenu = GetSubMenu(hMenu, 1);
   EnableMenuItem(hMenu, CM_ACQSINGLEIMAGE, MF_BYCOMMAND|MF_ENABLED);
   EnableMenuItem(hMenu, CM_ACQSEQIMAGES, MF_BYCOMMAND|MF_ENABLED);
   EnableMenuItem(hMenu, CM_ACQSEQIMAGES2, MF_BYCOMMAND|MF_ENABLED);
   if (stCameraInfo.bCanDoLiveMode)
      EnableMenuItem(hMenu, CM_ACQLIVEIMAGES, MF_BYCOMMAND|MF_ENABLED);
   if (stCameraInfo.bCanDoColor && stCameraInfo.bCanComputeExposure)
      EnableMenuItem(hMenu, CM_GETWHITEBAL, MF_BYCOMMAND|MF_ENABLED);
   if (stCameraInfo.bCanReadSensorTemperature)
      EnableMenuItem(hMenu, CM_READTEMPERATURE, MF_BYCOMMAND|MF_ENABLED);
}



void AcquireImages(BOOL bSequentialAcquisition, BOOL bAcquireUntilAborted)
{
   int nRetVal;
   HDC hDC;
   short asTemp[2];
   short sTemp;
   long  lTemp;
   BOOL  bTemp;
   RECT  stRect;
   BOOL  bDoAutoExposure = stCameraInfo.bCanComputeExposure;

   // Set parameters for acquisition.  These values are examples.
   (*pSpotSetValue)(SPOT_AUTOEXPOSE, &bDoAutoExposure);
   if (bDoAutoExposure)
   { // Auto-exposure
      sTemp = (short)SPOT_IMAGEBRIGHTFLD;  // Request bright-field exposure computation
      (*pSpotSetValue)(SPOT_IMAGETYPE, &sTemp);
      sTemp = (short)1;        // Limit the computed gain to 1
      (*pSpotSetValue)(SPOT_AUTOGAINLIMIT, &sTemp);
      lTemp = 1000;            // Set the brightness adj to 1.0
      (*pSpotSetValue)(SPOT_BRIGHTNESSADJX1000, &lTemp);
      sTemp = (short)10;       // Restrict the computed exposure time to be at least 10 ms
      (*pSpotSetValue)(SPOT_MINEXPOSUREMSEC, &sTemp);
   }
   else
   { // Manual exposure
      long lExpNanosecPerIncr;
      int  nExpTimeMS;
      SPOT_EXPOSURE_STRUCT2 stExposure;

      (*pSpotGetValue)(SPOT_EXPOSUREINCREMENT, &lExpNanosecPerIncr);
      memset(&stExposure, 0, sizeof(stExposure));
      stExposure.nGain = (short)1;     // Set the gain to 1
      nExpTimeMS = 50;                 // Use 50 ms for exposure time
      if (stCameraInfo.bCanDoColor && stCameraInfo.bDoesMultiShotColor)
      { // Set exposure for color acquisition
         stExposure.dwRedExpDur = nExpTimeMS * (1000000 / lExpNanosecPerIncr);
         stExposure.dwGreenExpDur = nExpTimeMS * (1000000 / lExpNanosecPerIncr);
         stExposure.dwBlueExpDur = nExpTimeMS * (1000000 / lExpNanosecPerIncr);
      }
      else  // Set exposure time for monochrome acquisition
         stExposure.dwExpDur = nExpTimeMS * (1000000 / lExpNanosecPerIncr);
      (*pSpotSetValue)(SPOT_EXPOSURE2, &stExposure);
   }
   /********************************
   stRect.left = 10; // Use a sub-area of the image sensor
   stRect.top = 24;
   stRect.right = stCameraInfo.nMaxImageWidth - 10;
   stRect.bottom = stCameraInfo.nMaxImageHeight - 24;
   (*pSpotSetValue)(SPOT_IMAGERECT, &stRect);
   ********************************/
   sTemp = 1;        // Don't do binning
   (*pSpotSetValue)(SPOT_BINSIZE, &sTemp);
   if (stCameraInfo.bCanDoColor)
   { // The camera can do color, so we will ask for a color image at 24 bpp
      nImageBitDepth = 24;
      sTemp = (short)nImageBitDepth;
      (*pSpotSetValue)(SPOT_BITDEPTH, &sTemp);
      if (stCameraInfo.bDoesMultiShotColor)
      { // The camera has a color filter
         SPOT_COLOR_ENABLE_STRUCT2 stColorEnable;

         stColorEnable.bEnableRed = stColorEnable.bEnableGreen =
            stColorEnable.bEnableBlue = TRUE;
         stColorEnable.bEnableClear = FALSE;
         (*pSpotSetValue)(SPOT_COLORENABLE2, &stColorEnable);  // Enable red, green, and blue
         (*pSpotSetValue)(SPOT_COLORORDER, "BRG");  // Set the acq order to blue-red-green
         bTemp = TRUE;      // Enable color enhancements
         (*pSpotSetValue)(SPOT_ENHANCECOLORS, &bTemp);
      }
   }
   else
   { // The camera can only acquire monochrome images
      nImageBitDepth = 8;             // Ask for 8 bpp images
      sTemp = (short)nImageBitDepth;
      (*pSpotSetValue)(SPOT_BITDEPTH, &sTemp);
   }
   if (stCameraInfo.bCanDoEdgeTrigger || stCameraInfo.bCanDoBulbTrigger)
   { // The camera has external trigger capability
      sTemp = (short)SPOT_TRIGMODENONE;  // Disable external triggering
      (*pSpotSetValue)(SPOT_EXTERNALTRIGGERMODE, &sTemp);
   }
   bTemp = TRUE;                      // Enable TTL output
   (*pSpotSetValue)(SPOT_ENABLETTLOUTPUT, &bTemp);
   if (stCameraInfo.bCanDoAccurateTTLOutputAndTriggerDelayTiming)
      lTemp = 15;      // Set the TTL output delay to 15 microseconds
   else lTemp = 1000;  // The camera can't time TTL output delay to the microsecond
   (*pSpotSetValue)(SPOT_TTLOUTPUTDELAY, &lTemp);
   bTemp = TRUE;                    // Enable chip defect corrections
   (*pSpotSetValue)(SPOT_CORRECTCHIPDEFECTS, &bTemp);
   (*pSpotSetValue)(SPOT_BIASFRMSUBTRACT, "");    // Disable bias frame subtraction
   (*pSpotSetValue)(SPOT_FLATFLDCORRECT, "");     // Disable flatfield correction
   (*pSpotSetValue)(SPOT_BKGDIMAGESUBTRACT, ""); // Disable thermal frame subtraction
   sTemp = (short)15;              // Enable noise filtering with a 15% threshold
   (*pSpotSetValue)(SPOT_NOISEFILTERTHRESPCT, &sTemp);
   // Set other parameters...

   // Now that the parameters have been set, ask the SpotCam driver how big the acquired image will be
   (*pSpotGetValue)(SPOT_ACQUIREDIMAGESIZE, asTemp);
   nImageWidth = asTemp[0];
   nImageHeight = asTemp[1];
   ComputeImageDisplayRect();
   bAbortFlag = FALSE;
   (*pSpotClearStatus)();
   InvalidateRect(hMainWindow, NULL, TRUE);  // Erase window
   AllocateImageBuffer();
   if (bSequentialAcquisition)
   {
      int nNumImages, nIntervalMSec;

      if (bAcquireUntilAborted)
      {
         nNumImages = SPOT_INFINITEIMAGES;   // Acquire images until aborted
         nIntervalMSec = SPOT_INTERVALSHORTASPOSSIBLE;  // Use the shortest possible interval
      }
      else
      {
         nNumImages = 5;   // Acquire 5 images
         nIntervalMSec = 1000;  // Use a 1 second interval
      }
      bBusy = TRUE;
      nRetVal = (*pSpotGetSequentialImages)(nNumImages, nIntervalMSec, FALSE, FALSE, FALSE, NULL);
#ifdef USE_SPOTWAITFORSTATUSCHANGE
      if (nRetVal == SPOT_RUNNING) nRetVal = WaitForOperationToFinish();
#endif // USE_SPOTWAITFORSTATUSCHANGE
      bBusy = FALSE;
      if (nRetVal != SPOT_SUCCESS)
      {
         DisplayError(nRetVal);
         return;
      }
   }
   else
   { // Single image acquisition
      bBusy = TRUE;
      nRetVal = (*pSpotGetImage)(0, FALSE, 0, pbyPixelData, NULL, NULL, NULL);
#ifdef USE_SPOTWAITFORSTATUSCHANGE
      if (nRetVal == SPOT_RUNNING) nRetVal = WaitForOperationToFinish();
#endif // USE_SPOTWAITFORSTATUSCHANGE
      bBusy = FALSE;
      if (nRetVal != SPOT_SUCCESS)
      {
         DisplayError(nRetVal);
         return;
      }
      hDC = GetDC(hMainWindow);
      DrawImage(hDC);
      ReleaseDC(hMainWindow, hDC);
   }
}


void RunLiveMode()
{
   int nRetVal;
   short sTemp, asTemp[2];
   short sColor, sRotateDirection;
   long  lTemp;
   BOOL  bTemp, bDoAutoExposure = stCameraInfo.bCanComputeExposure;
   RECT  stRect;

   if (bDoAutoExposure)
   { // Auto-exposure
      sTemp = (short)SPOT_IMAGEBRIGHTFLD;  // Request bright-field exposure computation
      (*pSpotSetValue)(SPOT_IMAGETYPE, &sTemp);
      sTemp = (short)1;        // Limit the computed gain to 1
      (*pSpotSetValue)(SPOT_LIVEAUTOGAINLIMIT, &sTemp);
      lTemp = 1000;            // Set the brightness adj to 1.0
      (*pSpotSetValue)(SPOT_LIVEBRIGHTNESSADJX1000, &lTemp);
      sTemp = (short)10;       // Restrict the computed exposure time to be at least 10 ms
      (*pSpotSetValue)(SPOT_MINEXPOSUREMSEC, &sTemp);
      bTemp = TRUE;            // Enable auto-brightness adjustment
      (*pSpotSetValue)(SPOT_LIVEAUTOBRIGHTNESS, &bTemp);
   }
   else
   { // Manual exposure
      long lExpNanosecPerIncr;
      int  nExpTimeMS;
      SPOT_EXPOSURE_STRUCT2 stExposure;

      (*pSpotGetValue)(SPOT_EXPOSUREINCREMENT, &lExpNanosecPerIncr);
      memset(&stExposure, 0, sizeof(stExposure));
      stExposure.nGain = (short)1;     // Set the gain to 1
      nExpTimeMS = 20;                 // Use 20 ms for exposure time
      if (stCameraInfo.bCanDoColor)
      { // Set exposure for color acquisition
         stExposure.dwRedExpDur = nExpTimeMS * 1000000 / lExpNanosecPerIncr;
         stExposure.dwGreenExpDur = nExpTimeMS * 1000000 / lExpNanosecPerIncr;
         stExposure.dwBlueExpDur = nExpTimeMS * 1000000 / lExpNanosecPerIncr;
      }
      else  // Set exposure time for monochrome acquisition
         stExposure.dwExpDur = nExpTimeMS * 1000000 / lExpNanosecPerIncr;
      (*pSpotSetValue)(SPOT_LIVEEXPOSURE, &stExposure);
      /*************** ENABLE THIS CODE TO USE LIVE IMAGE SCALING *********
      if (stCameraInfo.bCanDoLiveImageScaling)
      {
         SPOT_LIVE_IMAGE_SCALING_STRUCT stLiveImageScaling;

         memset(&stLiveImageScaling, 0, sizeof(stLiveImageScaling));
         stLiveImageScaling.bAutoScale = TRUE;
         stLiveImageScaling.fBlackOverflowPct = 1.5;  // Make at least 1.5% of the pixels black
         stLiveImageScaling.fWhiteOverflowPct = 3.7;  // Make at least 3.7% of the pixels white
         (*pSpotSetValue)(SPOT_LIVEIMAGESCALING, &stLiveImageScaling);
      }
      *********************************************************************/
   }
   if (stCameraInfo.bCanDoColor)
   {
      nImageBitDepth = 24;
      sColor = (short)SPOT_COLORRGB;
   }
   else
   {
      nImageBitDepth = 8;
      sColor = (short)SPOT_COLORNONE;
   }
   /****************************
   stRect.left = 10; // Use a sub-area of the image sensor
   stRect.top = 24;
   stRect.right = stCameraInfo.nMaxImageWidth - 10;
   stRect.bottom = stCameraInfo.nMaxImageHeight - 24;
   (*pSpotSetValue)(SPOT_IMAGERECT, &stRect);
   *****************************/
   sTemp = 1;        // Don't do binning
   (*pSpotSetValue)(SPOT_BINSIZE, &sTemp);
   // Set other parameters...

   // Now that the parameters have been set, ask the SpotCam driver how big the acquired image will be
   sRotateDirection = SPOT_ROTATERIGHT;     // Rotate live mode images right
   (*pSpotGetValue)(SPOT_ACQUIREDLIVEIMAGESIZE, asTemp);
   if (sRotateDirection != SPOT_ROTATENONE)
   {
      nImageWidth = asTemp[1];
      nImageHeight = asTemp[0];
   }
   else
   {
      nImageWidth = asTemp[0];
      nImageHeight = asTemp[1];
   }
   AllocateImageBuffer();
   ComputeImageDisplayRect();
   bAbortFlag = FALSE;
   InvalidateRect(hMainWindow, NULL, TRUE);  // Erase window
   (*pSpotClearStatus)();
   bBusy = TRUE;
   nRetVal = (*pSpotGetLiveImages)(bDoAutoExposure, sColor, sRotateDirection, FALSE, FALSE, pbyPixelData);
#ifdef USE_SPOTWAITFORSTATUSCHANGE
      if (nRetVal == SPOT_RUNNING) nRetVal = WaitForOperationToFinish();
#endif // USE_SPOTWAITFORSTATUSCHANGE
   bBusy = FALSE;
   if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      return;
   }
}


void GetWhiteBalance()
{
   int nRetVal;
   SPOT_WHITE_BAL_STRUCT stWhiteBal;

   if (MessageBox(hMainWindow, "Make sure that there is white in the camera's view",
                  szAppName, MB_OKCANCEL) == IDCANCEL) return;
   bBusy = TRUE;
   nRetVal = (*pSpotComputeWhiteBalance)(&stWhiteBal);
#ifdef USE_SPOTWAITFORSTATUSCHANGE
   if (nRetVal == SPOT_RUNNING) nRetVal = WaitForOperationToFinish();
#endif // USE_SPOTWAITFORSTATUSCHANGE
   bBusy = FALSE;
   if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      return;
   }
   (*pSpotSetValue)(SPOT_WHITEBALANCE, &stWhiteBal);  // Set the white balance for the driver to use
}


void ReadTemperature()
{
   int nRetVal;
   short nCurTemperature, nLastExpTemperature;
   BOOL  bIsNewValue;
   char  szMsg[93];

   nRetVal = (*pSpotGetSensorCurrentTemperature)(&nCurTemperature, &bIsNewValue);
   if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      return;
   }
   nRetVal = (*pSpotGetSensorExposureTemperature)(&nLastExpTemperature);
   if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      return;
   }
   sprintf(szMsg, "The current sensor temperature is %d.%u C,\n"
                  "and the temperature at the last exposure was %d.%u C",
           nCurTemperature/10, abs(nCurTemperature)%10,
           nLastExpTemperature/10, abs(nLastExpTemperature)%10);
   MessageBox(hMainWindow, szMsg, szAppName, MB_OK);
}


#ifdef USE_SPOTWAITFORSTATUSCHANGE
int WaitForOperationToFinish()
{
   int  nStatusVal;
   long lInfo;

   while (TRUE)
   {
      MSG stMsg;

      // Let OS messages be processed so that the user can abort, etc.
      while (PeekMessage(&stMsg, 0, 0, 0, PM_REMOVE))
      {
         if (stMsg.message == WM_QUIT)
         {
            PostQuitMessage(stMsg.wParam);  // make sure all loops exit
            break;
         }
         DispatchMessage(&stMsg);
      }
      if ((*pSpotWaitForStatusChange)(&nStatusVal, &lInfo, 250))
      { // The status has changed
         OurCallbackFunc(nStatusVal, lInfo, 0);
         switch (nStatusVal)
         {
         case SPOT_STATUSIDLE:
         case SPOT_STATUSABORTED:
         case SPOT_STATUSERROR:
            return((int)lInfo);
         }
      }
   }
}
#endif // USE_SPOTWAITFORSTATUSCHANGE



// This function is called by the SpotCam driver
void WINAPI OurCallbackFunc(int iStatus, long lInfo, DWORD dwUserData)
{
   char *pszStatusMsg=NULL;
   HDC hDC;

   // Display status
   switch (iStatus)
   {
   case SPOT_STATUSLIVEIMAGEREADY:
      hDC = GetDC(hMainWindow);    // Draw the image
      DrawImage(hDC);
      ReleaseDC(hMainWindow, hDC);
      pszStatusMsg = "Live Image Ready";
      break;
   case SPOT_STATUSSEQIMAGEREADY:
      // We can retrieve the image's timestamp here, if we wish
      // SpotGetExposureTimestamp(pstTimestamp);
      if (pbyPixelData)
      { // Retrieve the image from the SpotCam driver
         if ((*pSpotRetrieveSequentialImage)(pbyPixelData) == SPOT_SUCCESS)
         { // Draw the image
            hDC = GetDC(hMainWindow);
            DrawImage(hDC);
            ReleaseDC(hMainWindow, hDC);
         }
      }
      pszStatusMsg = "Sequential Image Ready";
      break;
   case SPOT_STATUSIDLE:
      pszStatusMsg = "Idle";
      break;
   case SPOT_STATUSDRVNOTINIT:
      pszStatusMsg = "Driver not Initialized";
      break;
   case SPOT_STATUSSHUTTEROPENRED:
      pszStatusMsg = "Exposing (red)";
      break;
   case SPOT_STATUSSHUTTEROPENGREEN:
      pszStatusMsg = "Exposing (green)";
      break;
   case SPOT_STATUSSHUTTEROPENBLUE:
      pszStatusMsg = "Exposing (blue)";
      break;
   case SPOT_STATUSSHUTTEROPENCLEAR:
      pszStatusMsg = "Exposing (clear)";
      break;
   case SPOT_STATUSSHUTTEROPEN:
      pszStatusMsg = "Exposing";
      break;
   case SPOT_STATUSIMAGEREADRED:
      pszStatusMsg = "Reading Image (red)";
      break;
   case SPOT_STATUSIMAGEREADGREEN:
      pszStatusMsg = "Reading Image (green)";
      break;
   case SPOT_STATUSIMAGEREADBLUE:
      pszStatusMsg = "Reading Image (blue)";
      break;
   case SPOT_STATUSIMAGEREADCLEAR:
      pszStatusMsg = "Reading Image (clear)";
      break;
   case SPOT_STATUSIMAGEREAD:
      pszStatusMsg = "Reading Image";
      break;
   case SPOT_STATUSCOMPEXP:
      pszStatusMsg = "Computing Exposure";
      break;
   case SPOT_STATUSCOMPWHITEBAL:
      pszStatusMsg = "Computing White Balance";
      break;
   case SPOT_STATUSGETIMAGE:
      pszStatusMsg = "Getting Image";
      break;
   case SPOT_STATUSSEQIMAGEWAITING:
      pszStatusMsg = "Waiting to Acquire Next Image";
      break;
   case SPOT_STATUSIMAGEPROCESSING:
      pszStatusMsg = "Processing Image";
      break;
   case SPOT_STATUSWAITINGFORTRIGGER:
      pszStatusMsg = "Waiting for Trigger";
      break;
   case SPOT_STATUSWAITINGFORBLOCKLIGHT:
      pszStatusMsg = "Block Light";
      break;
   case SPOT_STATUSWAITINGFORMOVETOBKGD:
      pszStatusMsg = "Move to Background";
      break;
   case SPOT_STATUSTTLOUTPUTDELAY:
      pszStatusMsg = "TTL Output Delay";
      break;
   case SPOT_STATUSEXTERNALTRIGGERDELAY:
      pszStatusMsg = "External Trigger Delay";
      break;
   case SPOT_STATUSWAITINGFORCOLORFILTER:
      pszStatusMsg = "Waiting for Color Filter";
      break;
   case SPOT_STATUSABORTED:
      pszStatusMsg = "Operation Aborted";
      break;
   case SPOT_STATUSERROR:
      pszStatusMsg = "Error";
      break;
   }
   if (pszStatusMsg) SetDlgItemText(hStatusDlg, IDC_STATUS, pszStatusMsg);
}


void ShutDown()
{
   bAbortFlag = TRUE;
   (*pSpotExit)();
   if (hImageBuffer)
   {
      GlobalUnlock(hImageBuffer);
      GlobalFree(hImageBuffer);
      hImageBuffer = NULL;
   }
}






BOOL AllocateImageBuffer()
{
   int nBufSize, nRowBytes, nPaletteSize;

   pstBitmapInfo = NULL;  // Reset these pointers
   pbyPixelData = NULL;
   if (hImageBuffer)
   {
      GlobalUnlock(hImageBuffer);
      GlobalFree(hImageBuffer);
      hImageBuffer = NULL;
   }
   switch (nImageBitDepth)
   {
   case 8:
      nRowBytes = ((nImageWidth * 8l + 31) / 32) * 4l;
      nPaletteSize = 256 * sizeof(RGBQUAD);
      break;
   case 24:
      nRowBytes = ((nImageWidth * 24l + 31) / 32) * 4l;
      nPaletteSize = 0;
      break;
   }
   // Create Windows BITMAP buffer
   nBufSize = nRowBytes * nImageHeight + sizeof(BITMAPINFOHEADER) + nPaletteSize;
   hImageBuffer = GlobalAlloc(GPTR, nBufSize);
   if (!hImageBuffer) return(FALSE);
   pstBitmapInfo = (BITMAPINFOHEADER *)GlobalLock(hImageBuffer);
   pbyPixelData = (BYTE *)pstBitmapInfo + sizeof(BITMAPINFOHEADER) + nPaletteSize;
   pstBitmapInfo->biSize = sizeof(BITMAPINFOHEADER);
   pstBitmapInfo->biWidth = nImageWidth;
   pstBitmapInfo->biHeight = nImageHeight;
   pstBitmapInfo->biPlanes = 1;
   pstBitmapInfo->biBitCount = (WORD)nImageBitDepth;
   pstBitmapInfo->biCompression = BI_RGB;
   pstBitmapInfo->biSizeImage = 0;
   pstBitmapInfo->biXPelsPerMeter = 1;
   pstBitmapInfo->biYPelsPerMeter = 1;
   pstBitmapInfo->biClrUsed = (nImageBitDepth>=24)?0:256;
   pstBitmapInfo->biClrImportant = 0;
   if (nImageBitDepth == 8)
   { // Create grayscale palette
      int ixEntry;

      for (ixEntry = 0; ixEntry < 256; ixEntry ++)
      {
         ((BITMAPINFO *)pstBitmapInfo)->bmiColors[ixEntry].rgbRed = (BYTE)ixEntry;
         ((BITMAPINFO *)pstBitmapInfo)->bmiColors[ixEntry].rgbGreen = (BYTE)ixEntry;
         ((BITMAPINFO *)pstBitmapInfo)->bmiColors[ixEntry].rgbBlue = (BYTE)ixEntry;
      }
   }
   return(TRUE);
}


void DrawImage(HDC hDC)
{
   if (!pstBitmapInfo || !pbyPixelData) return; // Nothing to paint!
   SetStretchBltMode(hDC, COLORONCOLOR);
   StretchDIBits(hDC, stImageDisplayRect.left, stImageDisplayRect.top,
                     stImageDisplayRect.right - stImageDisplayRect.left,
                 stImageDisplayRect.bottom - stImageDisplayRect.top, 0, 0,
                 nImageWidth, nImageHeight, pbyPixelData,
                 (CONST BITMAPINFO *)pstBitmapInfo, DIB_RGB_COLORS, SRCCOPY);
}


void EvPaint()
{
   PAINTSTRUCT stPaintInfo;

   BeginPaint(hMainWindow, &stPaintInfo);
   DrawImage(stPaintInfo.hdc);
   RestoreDC(stPaintInfo.hdc, -1);
   EndPaint(hMainWindow, &stPaintInfo);
}


void ComputeImageDisplayRect()
{
   RECT stClientRect;
   int  nClientWidth, nClientHeight;
   int  nRectWidth, nRectHeight;

   GetClientRect(hMainWindow, &stClientRect);
   nClientWidth = stClientRect.right - stClientRect.left;
   nClientHeight = stClientRect.bottom - stClientRect.top;
   if ((nClientWidth >= nImageWidth) && (nClientHeight >= nImageHeight))
   { // The whole image will fit in the window
      nRectWidth = nImageWidth;
      nRectHeight = nImageHeight;
   }
   else
   {
      float fImgAspectRatio;
      int   nTempHeight;

      fImgAspectRatio = (float)nImageWidth / nImageHeight;
      nTempHeight = (int)(nClientWidth / fImgAspectRatio + 0.5);
      if (nTempHeight > nClientHeight)
      { // Bound vertically
         nRectHeight = nClientHeight;
         nRectWidth = (int)(nRectHeight * fImgAspectRatio + 0.5);
      }
      else
      { // Bound horizontally
         nRectWidth = nClientWidth;
         nRectHeight = (int)(nRectWidth / fImgAspectRatio + 0.5);

      }
   }
   stImageDisplayRect.left = (nClientWidth - nRectWidth) / 2;
   stImageDisplayRect.right = stImageDisplayRect.left + nRectWidth;
   stImageDisplayRect.top = (nClientHeight - nRectHeight) / 2;
   stImageDisplayRect.bottom = stImageDisplayRect.top + nRectHeight;
}



BOOL CALLBACK _export StatusDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
   switch (message)
   {
   case WM_INITDIALOG:
      return(TRUE);
   default:
      return(FALSE);
   }
}


LRESULT CALLBACK _export MainWindowProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
   int nCmdID;

   switch (message)
   {
   case WM_CREATE:
      break;
   case WM_PAINT:
      EvPaint();
      break;
   case WM_SIZE:
      if (pstBitmapInfo)
      { // We have an image to draw so recompute the area to use
         ComputeImageDisplayRect();
      }
      break;
   case WM_COMMAND:
      nCmdID = LOWORD(wParam);
      if ((nCmdID >= CM_FIRSTCAMERA) && (nCmdID < (CM_FIRSTCAMERA + nNumCameras)))
      { // The user selected a camera
         if (nSelCameraIndex < 0)
         { // A camera has not yet been selected
            nSelCameraIndex = (short)(nCmdID - CM_FIRSTCAMERA);
            InitializeCamera();
         }
         break;
      }
      switch (nCmdID)
      {
      case CM_ACQSINGLEIMAGE:
         AcquireImages(FALSE, FALSE);
         break;
      case CM_ACQSEQIMAGES:
         AcquireImages(TRUE, FALSE);
         break;
      case CM_ACQSEQIMAGES2:
         AcquireImages(TRUE, TRUE);
         break;
      case CM_ACQLIVEIMAGES:
         RunLiveMode();
         break;
      case CM_GETWHITEBAL:
         GetWhiteBalance();
         break;
      case CM_READTEMPERATURE:
         ReadTemperature();
         break;
      case CM_ABORT:
         bAbortFlag = TRUE;
         break;
      case CM_EXIT:
         if (bBusy)
         {
            MessageBox(hMainWindow, "Abort the operation before closing", szAppName, MB_OK);
            return(0);
         }
         ShutDown();
         DestroyWindow(hWnd);
         break;
      default:
         break;
      }
      break;
   case WM_CLOSE:
      if (bBusy)
      {
         MessageBox(hMainWindow, "Abort the operation before closing", szAppName, MB_OK);
         return(0);
      }
      return(DefWindowProc(hWnd, message, wParam, lParam));
   case WM_DESTROY:
      ShutDown();
      PostQuitMessage(0);
      break;
   default:
      return(DefWindowProc(hWnd, message, wParam, lParam));
   }
   return(0);
}



void DisplayWarning(int nWarnCode)
{
   char *pszWarnText=NULL;

   switch (nWarnCode)
   {
   case SPOT_WARNUNSUPPCAMFEATURES:
      pszWarnText = "The camera has capabilities not supported by this version of the driver";
      break;
   case SPOT_WARNINVALIDINPUTICC:
      pszWarnText = "Missing or invalid input ICC profile";
      break;
   case SPOT_WARNINVALIDOUTPUTICC:
      pszWarnText = "Missing or invalid output ICC profile";
      break;
   }
   if (pszWarnText) MessageBox(hMainWindow, pszWarnText, szAppName, MB_OK|MB_ICONWARNING);
}


void DisplayError(int nErrCode)
{
   char *pszErrText=NULL;

   switch (nErrCode)
   {
   case SPOT_ERROUTOFMEMORY:
      pszErrText = "Out of Memory";
      break;
   case SPOT_ERREXPTOOSHORT:
      pszErrText = "The exposure is too short";
      break;
   case SPOT_ERREXPTOOLONG :
      pszErrText = "The exposure is too long";
      break;
   case SPOT_ERRNOCAMERARESP:
      pszErrText = "The camera is not responding";
      break;
   case SPOT_ERRVALOUTOFRANGE:
      pszErrText = "Parameter out of Range";
      break;
   case SPOT_ERRINVALIDPARAM:
      pszErrText = "Invalid Parameter";
      break;
   case SPOT_ERRDRVNOTINIT:
      pszErrText = "The SpotCam driver has not been initialized";
      break;
   case SPOT_ERRREGISTRYQUERY:
   case SPOT_ERRREGISTRYSET:
      pszErrText = "Registry access error";
      break;
   case SPOT_ERRDEVDRVLOAD:
      pszErrText = "Error unloading device driver";
      break;
   case SPOT_ERRCAMERAERROR:
      pszErrText = "Camera Error";
      break;
   case SPOT_ERRDRVALREADYINIT:
      pszErrText = "The SpotCam driver has already been initialized";
      break;
   case SPOT_ERRDMASETUP:
      pszErrText = "Error setting up DMA buffers";
      break;
   case SPOT_ERRREADCAMINFO:
      pszErrText = "Error reading camera information";
      break;
   case SPOT_ERRNOTCAPABLE:
      pszErrText = "The camera is not capable of the requested action";
      break;
   case SPOT_ERRCOLORFILTERNOTIN:
      pszErrText = "The color filter is not in the Color position";
      break;
   case SPOT_ERRCOLORFILTERNOTOUT:
      pszErrText = "The color filter is not in the B/W position";
      break;
   case SPOT_ERRCAMERABUSY:
      pszErrText = "The camera is currently busy";
      break;
   case SPOT_ERRCAMERANOTSUPPORTED:
      pszErrText = "The camera is not supported";
      break;
   case SPOT_ERRFILEOPEN:
      pszErrText = "Error opening file";
      break;
   case SPOT_ERRFLATFLDINCOMPATIBLE:
      pszErrText = "The flatfield is incompatible with the current camera/settings";
      break;
   case SPOT_ERRNODEVICESFOUND:
      pszErrText = "No devices found";
      break;
   case SPOT_ERRBRIGHTNESSCHANGED:
      pszErrText = "The brightness changed during exposure computation";
      break;
   case SPOT_ERRCAMANDCARDINCOMPATIBLE:
      pszErrText = "The camera is incompatible with the interface card";
      break;
   case SPOT_ERRBIASFRMINCOMPATIBLE:
      pszErrText = "The bias frame is incompatible with the current camera/settings";
      break;
   case SPOT_ERRBKGDIMAGEINCOMPATIBLE:
      pszErrText = "The background image is incompatible with the current camera/settings";
      break;
   case SPOT_ERRBKGDTOOBRIGHT:
      pszErrText = "The background is too bright";
      break;
   case SPOT_ERRINVALIDFILE:
      pszErrText = "Invalid file";
      break;
   case SPOT_ERRINSUF1394ISOCBANDWIDTH:
      pszErrText = "The required 1394 isochronous bandwidth is unavailable";
      break;
   case SPOT_ERRINSUF1394ISOCRESOURCES:
      pszErrText = "There are insufficient 1394 isochronous resources available";
      break;
   case SPOT_ERRNO1394ISOCCHANNEL:
      pszErrText = "No 1394 isochronous channel is available";
      break;
   }
   if(pszErrText)MessageBox(hMainWindow,pszErrText,szAppName,MB_OK|MB_ICONSTOP);
}



BOOL LoadSpotCamDLL()
{
   HKEY hKey;
   char szPath[MAX_PATH+15];
   DWORD dwSize;

   hSpotCamDLL = NULL;
   // Look for the Registry entry to tell us where to find SpotCam.dll
   if (RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Diagnostic Instruments, Inc.\\SPOT Camera for Windows", 0, KEY_QUERY_VALUE, &hKey) == ERROR_SUCCESS)
   {
      dwSize = MAX_PATH;
      if (RegQueryValueEx(hKey, "Driver Path", 0, NULL, (BYTE *)szPath, &dwSize) == ERROR_SUCCESS)
      {
         strcat(szPath, "\\SpotCam.dll");
         hSpotCamDLL = LoadLibrary(szPath);
      }
      RegCloseKey(hKey);
   }
   if (!hSpotCamDLL)   // Try loading SpotCam.dll from somewhere in the system PATH
      hSpotCamDLL = LoadLibrary("SpotCam.dll");
   if (hSpotCamDLL)
   { // Get the addresses of the API functions which we plan to call
      pSpotInit = (SPOTEXIT)GetProcAddress(hSpotCamDLL, "SpotInit");
      pSpotExit = (SPOTEXIT)GetProcAddress(hSpotCamDLL, "SpotExit");
      pSpotSetValue = (SPOTSETVALUE)GetProcAddress(hSpotCamDLL, "SpotSetValue");
      pSpotGetValue = (SPOTGETVALUE)GetProcAddress(hSpotCamDLL, "SpotGetValue");
      pSpotGetCameraAttributes = (SPOTGETCAMERAATTRIBUTES)GetProcAddress(hSpotCamDLL, "SpotGetCameraAttributes");
      pSpotGetVersionInfo2 = (SPOTGETVERSIONINFO2)GetProcAddress(hSpotCamDLL, "SpotGetVersionInfo2");
      pSpotComputeExposure2 = (SPOTCOMPUTEEXPOSURE2)GetProcAddress(hSpotCamDLL, "SpotComputeExposure2");
      pSpotComputeWhiteBalance = (SPOTCOMPUTEWHITEBALANCE)GetProcAddress(hSpotCamDLL, "SpotComputeWhiteBalance");
      pSpotGetImage = (SPOTGETIMAGE)GetProcAddress(hSpotCamDLL, "SpotGetImage");
      pSpotGetLiveImages = (SPOTGETLIVEIMAGES)GetProcAddress(hSpotCamDLL, "SpotGetLiveImages");
      pSpotGetSequentialImages = (SPOTGETSEQUENTIALIMAGES)GetProcAddress(hSpotCamDLL, "SpotGetSequentialImages");;
      pSpotRetrieveSequentialImage = (SPOTRETRIEVESEQUENTIALIMAGE)GetProcAddress(hSpotCamDLL, "SpotRetrieveSequentialImage");
      pSpotSetAbortFlag = (SPOTSETABORTFLAG)GetProcAddress(hSpotCamDLL, "SpotSetAbortFlag");
      pSpotSetCallback = (SPOTSETCALLBACK)GetProcAddress(hSpotCamDLL, "SpotSetCallback");
      pSpotSetDeviceNotificationCallback = (SPOTSETDEVICENOTIFICATIONCALLBACK)GetProcAddress(hSpotCamDLL, "SpotSetDeviceNotificationCallback");
      pSpotClearStatus = (SPOTCLEARSTATUS)GetProcAddress(hSpotCamDLL, "SpotClearStatus");
      pSpotFindDevices = (SPOTFINDDEVICES)GetProcAddress(hSpotCamDLL, "SpotFindDevices");
      pSpotGetExposureTimestamp = (SPOTGETEXPOSURETIMESTAMP)GetProcAddress(hSpotCamDLL, "SpotGetExposureTimestamp");
      pSpotGetSensorCurrentTemperature = (SPOTGETSENSORCURRENTTEMPERATURE)GetProcAddress(hSpotCamDLL, "SpotGetSensorCurrentTemperature");
      pSpotGetSensorExposureTemperature = (SPOTGETSENSOREXPOSURETEMPERATURE)GetProcAddress(hSpotCamDLL, "SpotGetSensorExposureTemperature");
      pSpotWaitForStatusChange = (SPOTWAITFORSTATUSCHANGE)GetProcAddress(hSpotCamDLL, "SpotWaitForStatusChange");
      pSpotGetCameraErrorCode = (SPOTGETCAMERAERRORCODE)GetProcAddress(hSpotCamDLL, "SpotGetCameraErrorCode");
   }
   return(hSpotCamDLL!=NULL);
}



int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrevInstance,
                   LPSTR lpszCmdLine, int cmdShow)
{
   MSG msg;
   WNDCLASS stWindowClass;
   int nRetVal;
   int ixDevice;
   SPOT_DEVICE_STRUCT astDevices[SPOT_MAX_DEVICES];
   MENUITEMINFO stMenuItemInfo;
   HMENU hMenu;

   hInstance = hInst;
   if (!LoadSpotCamDLL())
   {
      MessageBox(0, "Error Loading SpotCam.dll!", szAppName, MB_ICONERROR|MB_OK|MB_TOPMOST);
      return(-1);
   }
   // Create the main app window
   stWindowClass.style = CS_HREDRAW | CS_VREDRAW;
   stWindowClass.lpfnWndProc = MainWindowProc;
   stWindowClass.cbClsExtra = 0;
   stWindowClass.cbWndExtra = 0;
   stWindowClass.hInstance = hInstance;
   stWindowClass.hIcon = LoadIcon(hInstance, szWindowClassName);
   stWindowClass.hCursor = LoadCursor(NULL, IDC_ARROW);
   stWindowClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
   stWindowClass.lpszClassName = szWindowClassName;
   stWindowClass.lpszMenuName = szWindowClassName;
   RegisterClass(&stWindowClass);
   hMainWindow = CreateWindow(szWindowClassName, (LPSTR)szAppName,
                              WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                              CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);
   ShowWindow(hMainWindow, cmdShow);

   SendMessage(hMainWindow, WM_SETICON, ICON_SMALL, (LPARAM)LoadIcon(hInst, "AppIcon"));

   // Show the user the list of available cameras
   hMenu = GetMenu(hMainWindow);
   hMenu = GetSubMenu(hMenu, 0);
   memset(&stMenuItemInfo, 0, sizeof(stMenuItemInfo));
   stMenuItemInfo.cbSize = sizeof(stMenuItemInfo);
   stMenuItemInfo.fMask = MIIM_ID|MIIM_TYPE;
   stMenuItemInfo.fType = MFT_STRING;
   // Look for connected cameras
   nRetVal = (*pSpotFindDevices)(astDevices, &nNumCameras);
   if (nRetVal != SPOT_SUCCESS)
   {
      DisplayError(nRetVal);
      return(0);
   }
   for (ixDevice = 0; ixDevice < nNumCameras; ixDevice ++)
   {
      stMenuItemInfo.wID = CM_FIRSTCAMERA + ixDevice;
      stMenuItemInfo.dwTypeData = astDevices[ixDevice].szDescription;
      InsertMenuItem(hMenu, ixDevice, TRUE, &stMenuItemInfo);
   }
   UpdateWindow(hMainWindow);

   // Main message loop
   while (GetMessage(&msg, NULL, 0, 0))
   {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
   }  // while
   if (hSpotCamDLL) FreeLibrary(hSpotCamDLL);   // Unload SpotCam.dll
   return(msg.wParam);
}


