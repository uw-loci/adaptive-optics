// SpotCam SDK ver 4.7 Header

#ifndef _SpotCamH_
#define _SpotCamH_


#if defined(_WINDOWS) && !defined(_Windows)
#define _Windows
#endif // _WINDOWS


#if defined( TARGET_OS_MAC ) && TARGET_OS_MAC
   #ifndef macintosh
      #define macintosh    1
   #endif

	#ifndef VOID
		#define VOID void
	#endif

	#ifndef WINAPI
		#define WINAPI
	#endif

	#ifdef __OBJC__

	#else
      typedef signed char	BOOL;
	#endif

	typedef unsigned short	WORD;
	typedef unsigned long 	DWORD;
	typedef unsigned long long QWORD;
	typedef unsigned char	BYTE;

   typedef Rect SPOT_RECT;

#elif defined(_Windows)

typedef unsigned __int64 QWORD;
typedef RECT SPOT_RECT;

#elif defined(unix)

typedef int                BOOL;
typedef unsigned char      BYTE;
typedef unsigned short     WORD;
typedef unsigned long      DWORD;
typedef unsigned long long QWORD;

typedef struct
{
   int left, top;
   int right, bottom;
} SPOT_RECT;

#define WINAPI
#define VOID  void

#endif // TARGET_OS_MAC, _Windows, unix



#define SPOT_MAX_INTF_CARDS      25
#define SPOT_MAX_DEVICES         25
#define SPOT_MAX_SAMPLE_FRAMES   50


// Spot Function Return Codes
#define SPOT_SUCCESS                     0
// Warning Codes have Negative Values
#define SPOT_WARNUNSUPPCAMFEATURES      -100 // The camera has features which are not supported by this software version
#define SPOT_WARNINVALIDINPUTICC        -101 // The input color profile for the camera cannot be found or is invalid
#define SPOT_WARNINVALIDOUTPUTICC       -102 // The output color profile for the camera cannot be found or is invalid
// Error Codes have Positive Values below 1000
#define SPOT_ABORT                       100 // Operation was aborted by the app
#define SPOT_ERROUTOFMEMORY              101 // Memory allocation failure
#define SPOT_ERREXPTOOSHORT              102 // Exposure times is too short
#define SPOT_ERREXPTOOLONG               103 // Exposure times is too long
#define SPOT_ERRNOCAMERARESP             104 // Camera is not responding to command
#define SPOT_ERRVALOUTOFRANGE            105 // Specified value is out of valid range
#define SPOT_ERRINVALIDPARAM             106 // Specified parameter number is not valid
#define SPOT_ERRDRVNOTINIT               107 // SpotInit has not yet been successfully called
#define SPOT_ERRREGISTRYQUERY            109 // Error getting value from Windows Registry
#define SPOT_ERRREGISTRYSET              110 // Error setting value in Windows Registry
#define SPOT_ERRDEVDRVLOAD               112 // Error loading device driver
#define SPOT_ERRCAMERAERROR              114 // Camera is malfunctioning
#define SPOT_ERRDRVALREADYINIT           115 // SpotInit has already been called
#define SPOT_ERRDMASETUP                 117 // The DMA buffer could not be setup
#define SPOT_ERRREADCAMINFO              118 // There was an eror reading the camera information
#define SPOT_ERRNOTCAPABLE               119 // The camera or driver is not capable of performing the command
#define SPOT_ERRCOLORFILTERNOTIN         120 // The color filter is not in the IN position
#define SPOT_ERRCOLORFILTERNOTOUT        121 // The color filter is not in the OUT position
#define SPOT_ERRCAMERABUSY               122 // The camera is currently in another operation
#define SPOT_ERRCAMERANOTSUPPORTED       123 // The camera model is not supported by this version
#ifdef macintosh
#define SPOT_PROCESSERROR				     124 // Process Manager can't get info for us.
#define SPOT_ERRMISC					        135 // misc Mac error
#endif
#define SPOT_ERRNOIMAGEAVAILABLE         125 // There is no image available
#define SPOT_ERRFILEOPEN                 126 // The specified file cannot be opened or created
#define SPOT_ERRFLATFLDINCOMPATIBLE      127 // The specified flatfield is incompatible with
                                             // the current camera/parameters
#define SPOT_ERRNODEVICESFOUND           128 // No SPOT interface cards or cameras were found
#define SPOT_ERRBRIGHTNESSCHANGED        129 // The brightness changed while exposure was being computed
#define SPOT_ERRCAMANDCARDINCOMPATIBLE   130 // The camera is incompatible with the interface card
#define SPOT_ERRBIASFRMINCOMPATIBLE      131 // The specified bias frame is incompatible with
                                             // the current camera/parameters
#define SPOT_ERRBKGDIMAGEINCOMPATIBLE    132 // The specified background image is incompatible with
                                             // the current camera/parameters
#define SPOT_ERRBKGDTOOBRIGHT            133 // The background is too bright to acquire a background image
#define SPOT_ERRINVALIDFILE              134 // The specified file is invalid
#define SPOT_ERRIMAGETOOBRIGHT           136 // The image is too bright
#define SPOT_ERRNOTHINGTODO              137 // There is nothing to do
#define SPOT_ERRNOCAMERAPOWER            138 // The camera is powered off
#define SPOT_ERRINSUF1394ISOCBANDWIDTH   201 // The is insufficient isochronous bandwidth available on the 1394 bus
#define SPOT_ERRINSUF1394ISOCRESOURCES   202 // The is insufficient 1394 isochronous resources available
#define SPOT_ERRNO1394ISOCCHANNEL        203 // The is no isochronous channel available on the 1394 bus
#define SPOT_ERRUSBVERSIONLOWERTHAN2     204 // The USB bus version is lower than 2.0

#define SPOT_RUNNING                    1001 // The process is running (only applicable when SPOT_WAITFORSTATUSCHANGES is TRUE)



// Image Sensor Types for Use with SPOT_IMAGESENSORTYPE
#define SPOT_IMAGESENSORTYPE_CCDINTERLINE        0x0011 // Conventional interline CCD
#define SPOT_IMAGESENSORTYPE_CCDFULLFRAME        0x0021 // Conventional full-frame CCD
#define SPOT_IMAGESENSORTYPE_CCDFRAMETRANSFER    0x0031 // Conventional frame-transfer CCD
#define SPOT_IMAGESENSORTYPE_CCDINTERLINEEM      0x0111 // Electron-Multiplication interline CCD
#define SPOT_IMAGESENSORTYPE_CCDFRAMETRANSFEREM  0x0131 // Electron-Multiplication frame-transfer CCD
#define SPOT_IMAGESENSORTYPE_CMOSROLLINGSHUTTER  0x0042 // CMOS rolling shutter
#define SPOT_IMAGESENSORTYPE_CMOSGLOBALSHUTTER   0x0012 // CMOS global shutter


// Color Values Used with SpotGetLiveImages
#define SPOT_COLORRED                    1
#define SPOT_COLORGREEN                  2
#define SPOT_COLORBLUE                   3
#define SPOT_COLORCLEAR                 10
#define SPOT_COLORRGB                    0
#define SPOT_COLORRG                    21   // Red-Green
#define SPOT_COLORRB                    22   // Red-Blue
#define SPOT_COLORGB                    23   // Green-Blue
#define SPOT_COLORNONE                  99


// Rotate Values Used with SpotGetLiveImages
#define SPOT_ROTATENONE         0
#define SPOT_ROTATELEFT         1
#define SPOT_ROTATERIGHT        2


// Color Enhancement Rendering Intent Values for Use with SPOT_COLORRENDERINGINTENT
#define SPOT_COLORRENDERINGINTENT_RELATIVECOLORIMETRIC  1
#define SPOT_COLORRENDERINGINTENT_ABSOLUTECOLORIMETRIC  2
#define SPOT_COLORRENDERINGINTENT_PERCEPTUAL            3
#define SPOT_COLORRENDERINGINTENT_SATURATION            4


// Image Types for Use with SPOT_IMAGETYPE
#define SPOT_IMAGEBRIGHTFLD              1
#define SPOT_IMAGEDARKFLD                2


// External Trigger Types for Use with SPOT_EXTERNALTRIGGERMODE
#define SPOT_TRIGMODENONE      0   // No trigger
#define SPOT_TRIGMODEEDGE      1   // Edge Trigger
#define SPOT_TRIGMODEBULB      2   // Bulb Trigger


// Bus Bandwidth Levels for Use with SPOT_BUSBANDWIDTH
#define SPOT_HIGHBW            1
#define SPOT_MEDIUMBW          2
#define SPOT_LOWBW             3


// External Trigger Active States for Use with SPOT_EXTERNALTRIGGERACTIVESTATE
#define SPOT_TRIGACTIVESTATE_LOW    0
#define SPOT_TRIGACTIVESTATE_HIGH   1


// TTL Output Active States for Use with SPOT_TTLOUTPUTACTIVESTATE
#define SPOT_TTLACTIVESTATE_LOW     0
#define SPOT_TTLACTIVESTATE_HIGH    1


// Values for Use with SpotGetSequentialImages
#define SPOT_INTERVALSHORTASPOSSIBLE   (-1)
#define SPOT_INFINITEIMAGES            (0x7fffffff)


// Mosaic Pattern Types for Use with SPOT_MOSAICPATTERN
#define SPOT_MOSAICBAYERGRBG   1   // Bayer pattern - Even lines: GRG.. Odd lines: BGB...  (zero-based)
#define SPOT_MOSAICBAYERRGGB   2   // Bayer pattern - Even lines: RGR.. Odd lines: GBG...
#define SPOT_MOSAICBAYERBGGR   3   // Bayer pattern - Even lines: BGB.. Odd lines: RGR...
#define SPOT_MOSAICBAYERGBRG   4   // Bayer pattern - Even lines: GBG.. Odd lines: RGR...


// 24 BPP Image Formats for Use with SPOT_24BPPIMAGEBUFFERFORMAT
#define SPOT_24BPPIMAGEBUFFERFORMATBGR   1   // Blue, Green, Red (3 bytes per pixel with padding) (standard Window BITMAP)
#define SPOT_24BPPIMAGEBUFFERFORMATRGB   2   // Red, Green, Blue (3 bytes per pixel with padding)
#define SPOT_24BPPIMAGEBUFFERFORMATARGB  3   // Alpha, Red, Green, Blue (4 bytes per pixel)
#define SPOT_24BPPIMAGEBUFFERFORMATABGR  4   // Alpha, Blue, Green, Red (4 bytes per pixel)
#define SPOT_24BPPIMAGEBUFFERFORMATRGBA  5   // Red, Green, Blue, Alpha (4 bytes per pixel)
#define SPOT_24BPPIMAGEBUFFERFORMATBGRA  6   // Blue, Green, Red, Alpha (4 bytes per pixel)


// Gain Port Attribute Flags for Use with SPOT_PORTnGAINATTRIBUTES
#define SPOT_GAINATTR_COMPUTABLE    0x01  // The actual gain can be computed with SpotGetActualGainValue() or SpotGetActualLiveGainValue()
#define SPOT_GAINATTR_SAMEASPORT0   0x02  // This gain port is the same as port 0, except that a range is provided (instead of a discrete value list)
#define SPOT_GAINATTR_ELECTRONMULT  0x04  // Electron multiplication gain
#define SPOT_GAINATTR_GATING        0x08  // Gating gain


// Shutter Modes for Use with SPOT_SHUTTERMODE
#define SPOT_SHUTTERMODE_NORMAL        0
#define SPOT_SHUTTERMODE_OPEN          1
#define SPOT_SHUTTERMODE_CLOSED        2


// Sensor Clear Modes for Use with SPOT_SENSORCLEARMODE and SPOT_SENSORCLEARMODES
#define SPOT_SENSORCLEARMODE_CONTINUOUS    0x01   // Continuously clear sensor
#define SPOT_SENSORCLEARMODE_PREEMPTABLE   0x02   // Allow exposures to pre-emp sensor clearing
#define SPOT_SENSORCLEARMODE_NEVER         0x04   // Never clear sensor


// Sensor Response Modes for use with SPOT_SENSORRESPONSEMODE
#define SPOT_SENSORRESPMODE_IR               0x01  // Enhanced IR response
#define SPOT_SENSORRESPMODE_DYNAMICRANGE     0x02  // Enhanced dynamic range
#define SPOT_SENSORRESPMODE_SENSITIVITY      0x04  // Enhanced sensitivity
#define SPOT_SENSORRESPMODE_ANTIBLOOMING     0x08  // Enhanced anti-blooming
#define SPOT_SENSORRESPMODE_GLOWSUPPRESSION  0x10  // Suppression of sensor glow


// Control Flags for Use with SpotUpdateFirmware
#define SPOT_UPDATEFWCONTROL_FORCEUPDATECAMERA      1  // Load camera firmware even if older than current
#define SPOT_UPDATEFWCONTROL_FORCEUPDATEINTFCARD    2  // Load interface card firmware even if older than current


// Result Flags for Use with SpotUpdateFirmware
#define SPOT_UPDATEFWRESULT_POWEROFFDEV        1  // Power off the device before using
#define SPOT_UPDATEFWRESULT_POWEROFFCOMPUTER   2  // Power off the computer before using the camera
#define SPOT_UPDATEFWRESULT_REBOOTCOMPUTER     4  // Reboot the computer before using the camera


// Message Types for Use in SPOT_MESSAGE_STRUCT
#define SPOT_MESSAGETYPE_INFO               1
#define SPOT_MESSAGETYPE_WARNING            2
#define SPOT_MESSAGETYPE_ERROR              3


// Parameters for use with SpotSetValue() and SpotGetValue()
#define SPOT_AUTOEXPOSE                    100   // BOOL
#define SPOT_BRIGHTNESSADJ                 101   // float
#define SPOT_AUTOGAINLIMIT                 102   // short
#define SPOT_BINSIZE                       103   // short
#define SPOT_IMAGERECT                     104   // SPOT_RECT structure
#define SPOT_EXPOSURE2                     105   // SPOT_EXPOSURE_STRUCT2
#define SPOT_EXPOSURE                      106   // SPOT_EXPOSURE_STRUCT
#define SPOT_COLORENABLE                   108   // SPOT_COLOR_ENABLE_STRUCT
#define SPOT_COLORORDER                    109   // char * (eg. "RGB", etc)
#define SPOT_WHITEBALANCE                  110   // SPOT_WHITE_BAL_STRUCT
#define SPOT_IMAGETYPE                     111   // short (SPOT_IMAGEBRIGHTFLD or SPOT_IMAGEDARKFLD)
#define SPOT_CORRECTCHIPDEFECTS            112   // BOOL
#define SPOT_BITDEPTH                      113   // short
#define SPOT_MESSAGEENABLE                 114   // BOOL
#define SPOT_WHITEBALANCEX1000             115   // SPOT_WHITE_BAL_INT_STRUCT
#define SPOT_BRIGHTNESSADJX1000            116   // long
#define SPOT_LIVEBRIGHTNESSADJ             118   // float
#define SPOT_LIVEBRIGHTNESSADJX1000        119   // long
#define SPOT_LIVEAUTOGAINLIMIT             200   // short
#define SPOT_SUBTRACTBLACKLEVEL            201   // BOOL
#define SPOT_MONITORFILTERPOS              202   // BOOL
#define SPOT_COLORENABLE2                  203   // SPOT_COLOR_ENABLE_STRUCT2
#define SPOT_DRIVERDEVICENUMBER            204   // short
#define SPOT_ENABLETTLOUTPUT               205   // BOOL
#define SPOT_TTLOUTPUTDELAYMS              206   // short (value in ms)
#define SPOT_LIVEGAMMAADJ                  207   // float
#define SPOT_LIVEGAMMAADJX1000             208   // long
#define SPOT_LIVEEXPOSURE                  210   // SPOT_EXPOSURE_STRUCT2
#define SPOT_MINEXPOSUREMSEC               211   // short
#define SPOT_RETURNRAWMOSAICDATA           212   // BOOL
#define SPOT_LIVEACCELERATIONLEVEL         213   // short
#define SPOT_ENHANCECOLORS                 214   // BOOL
#define SPOT_FLATFLDCORRECT                215   // NULL-terminated file name string
#define SPOT_NOISEFILTERTHRESPCT           216   // short
#define SPOT_LIVEAUTOBRIGHTNESS            217   // BOOL
#define SPOT_LIVEMAXEXPOSUREMSEC           220   // long
#define SPOT_EXPOSUREINCREMENT             221   // long
#define SPOT_EXTERNALTRIGGERMODE           222   // short (SPOT_TRIGMODENONE, SPOT_TRIGMODEEDGE, or SPOT_TRIGMODEBULB)
#define SPOT_MAXEXPOSUREMSEC               223   // long
#define SPOT_WHITEBALCOMPRECT              224   // SPOT_RECT structure
#define SPOT_BIASFRMSUBTRACT               225   // NULL-terminated file name string
#define SPOT_DEVICEUID                     226   // SPOT_DEVICE_UID union
#define SPOT_BUSBANDWIDTH                  227   // short (SPOT_HIGHBW, SPOT_MEDIUMBW, or SPOT_LOWBW)
#define SPOT_EXPOSURECOMPRECT              228   // SPOT_RECT structure
#define SPOT_EXTERNALTRIGGERACTIVESTATE    229   // short (SPOT_TRIGACTIVESTATE_LOW or SPOT_TRIGACTIVESTATE_HIGH)
#define SPOT_EXTERNALTRIGGERDELAY          230   // long (value in microseconds)
#define SPOT_REGULATETEMPERATURE           231   // BOOL
#define SPOT_REGULATEDTEMPERATURE          232   // short (degrees C * 100)
#define SPOT_HORIZREADOUTFREQUENCY         233   // long (value in kHz)
#define SPOT_TTLOUTPUTACTIVESTATE          234   // short (SPOT_TTLACTIVESTATE_LOW or SPOT_TTLACTIVESTATE_HIGH)
#define SPOT_TTLOUTPUTDELAY                235   // long (value in microseconds)
#define SPOT_BKGDIMAGESUBTRACT             236   // NULL-terminated file name string
#define SPOT_GAINPORTNUMBER                237   // short (0=port 0, 1=port 1, etc.)
#define SPOT_COLORRENDERINGINTENT          238   // short (one of the SPOT_COLORRENDERINGINTENT_xxx values)
#define SPOT_LIVEENHANCECOLORS             239   // BOOL
#define SPOT_PIXELRESOLUTIONLEVEL          240   // short (0=normal, 1+=higher, -1-=lower)
#define SPOT_INPUTCOLORPROFILE             241   // NULL-terminated file name string
#define SPOT_OUTPUTCOLORPROFILE            242   // NULL-terminated file name string
#define SPOT_COLORBINSIZE                  243   // short
#define SPOT_SENSORCLEARMODE               244   // DWORD
#define SPOT_COOLINGLEVEL                  245   // short
#define SPOT_FANSPEED                      246   // short
#define SPOT_FANEXPOSURESPEED              247   // short (fan speed to use during exposure, -1 to disable option)
#define SPOT_FANEXPOSUREDELAYMS            248   // short (value in ms)
#define SPOT_PREAMPGAINVAL                 249   // float
#define SPOT_VERTSHIFTPERIOD               250   // long  (value in ns)
#define SPOT_VERTCLOCKVOLTAGEBOOST         251   // short
#define SPOT_READOUTCIRCUIT                252   // short
#define SPOT_NUMBERSKIPLINES               253   // short
#define SPOT_SHUTTERMODE                   254   // short (SPOT_SHUTTERMODE_NORMAL, SPOT_SHUTTERMODE_OPEN, or SPOT_SHUTTERMODE_CLOSED)
#define SPOT_ENABLEPOWERSTATECONTROL       260   // BOOL
#define SPOT_FORCESINGLECHANLIVEMODE       261   // BOOL
#define SPOT_LIVEIMAGESCALING              262   // SPOT_LIVE_IMAGE_SCALING_STRUCT (or NULL-pointer to disable)
#define SPOT_LIVEHISTOGRAM                 263   // SPOT_LIVE_HISTOGRAM_STRUCT (or NULL-pointer to disable)
#define SPOT_SENSORRESPONSEMODE            264   // DWORD
#define SPOT_SEQIMAGEDISKCACHEPATH         265   // NULL-terminated directory name string
#define SPOT_SEQIMAGEEXPDURS               266   // array of DWORDs (1st val is count)
#define SPOT_LIVESUBTRACTBLACKLEVEL        267   // BOOL
#define SPOT_LIVEPIXELRESOLUTIONLEVEL      268   // short (0=normal, 1+=higher, -1-=lower)
#define SPOT_COOLERMODEONEXIT              269   // short (0=off, 1=on)
#define SPOT_WAITFORSTATUSCHANGES          501   // BOOL
#define SPOT_IMAGEORIENTATION              701   // short (1=top-first, -1=bottom-first)
#define SPOT_24BPPIMAGEBUFFERFORMAT        702   // short
#define SPOT_NUMBERBYTESPERIMAGEROW        703   // long


// Parameters for use with SpotGetValue()
#define SPOT_BRIGHTNESSADJLIMITS           120   // array of two floats
#define SPOT_BINSIZELIMITS                 121   // array of two shorts - Use SPOT_BINSIZES instead
#define SPOT_MAXIMAGERECTSIZE              122   // array of two shorts (ie. max width, max height)
#define SPOT_GAINVALS8                     123   // array of shorts (1st val is count)
#define SPOT_GAINVALS16                    129   // array of shorts (1st val is count)
#define SPOT_BITDEPTHS                     124   // array of shorts (1st val is count)
#define SPOT_BRIGHTNESSADJLIMITSX1000      125   // array of two longs
#define SPOT_EXPOSURELIMITS                126   // array of two longs (min, max in msec)
#define SPOT_EXPOSURELIMITS2               127   // array of two DWORDs (min, max exposure)
#define SPOT_LIVEGAINVALS                  128   // array of shorts (1st val is count)
#define SPOT_MAXLIVEACCELERATIONLEVEL      130   // short
#define SPOT_MAXWHITEBALANCERATIO          131   // float
#define SPOT_MAXWHITEBALANCERATIOX1000     132   // long
#define SPOT_MINEXPOSUREINCREMENT          133   // long (value in nanoseconds)
#define SPOT_EXPOSURECONVFACTOR            134   // float
#define SPOT_EXPOSURECONVFACTORX1000       135   // long
#define SPOT_MOSAICPATTERN                 136   // short (one of the SPOT_MOSAICxxx values)
#define SPOT_EXTERNALTRIGGERDELAYLIMITS    137   // array of two longs (min, max values in microseconds)
#define SPOT_REGULATEDTEMPERATURELIMITS    138   // array of two shorts (degrees C * 10)
#define SPOT_HORIZREADOUTFREQUENCIES       139   // array of longs (1st val is count)
#define SPOT_TTLOUTPUTDELAYLIMITS          140   // array of two longs (min, max values in microseconds)
#define SPOT_EXPOSURERESOLUTION            141   // long (value in nanoseconds)
#define SPOT_MAXGAINPORTNUMBER             144   // short
#define SPOT_PORT0GAINVALS8                SPOT_GAINVALS8    // array of shorts (1st val is count)
#define SPOT_PORT0GAINVALS16               SPOT_GAINVALS16   // array of shorts (1st val is count)
#define SPOT_PORT0LIVEGAINVALS             SPOT_LIVEGAINVALS // array of shorts (1st val is count)
#define SPOT_PORT1GAINVALLIMITS            145   // array of two longs (min, max port 1 gain values)
#define SPOT_PORT1LIVEGAINVALLIMITS        146   // array of two longs (min, max port 1 gain values)
#define SPOT_PORT2GAINVALLIMITS            147   // array of two longs (min, max port 2 gain values)
#define SPOT_PORT2LIVEGAINVALLIMITS        148   // array of two longs (min, max port 2 gain values)
#define SPOT_PORT3GAINVALLIMITS            149   // array of two longs (min, max port 3 gain values)
#define SPOT_PORT3LIVEGAINVALLIMITS        150   // array of two longs (min, max port 3 gain values)
#define SPOT_BINSIZES                      151   // array of shorts (1st val is count)
#define SPOT_MAXPIXELRESOLUTIONLEVEL       152   // short
#define SPOT_ACQUIREDIMAGESIZE             153   // array of two shorts (ie. width, height)
#define SPOT_ACQUIREDLIVEIMAGESIZE         154   // array of two shorts (ie. width, height)
#define SPOT_MINIMAGERECTSIZE              155   // array of two shorts (ie. min width, min height)
#define SPOT_COLORBINSIZES                 156   // array of shorts (1st val is count)
#define SPOT_LIVEAUTOBRIGHTNESSADJ         218   // float
#define SPOT_LIVEAUTOBRIGHTNESSADJX1000    219   // long
#define SPOT_PIXELSIZE                     401   // array of two longs (x, y sizes in nm)
#define SPOT_COOLINGLEVELS                 403   // array of two shorts (min, max)
#define SPOT_FANSPEEDS                     404   // array of two shorts (min, max)
#define SPOT_NUMBERREADOUTCIRCUITS         405   // short
#define SPOT_PREAMPGAINVALS                406   // array of floats (1st val is count)
#define SPOT_VERTSHIFTPERIODS              407   // array of longs (1st val is count)
#define SPOT_MAXVERTCLOCKVOLTAGEBOOST      408   // short
#define SPOT_PORT0GAINATTRIBUTES           411   // DWORD
#define SPOT_PORT1GAINATTRIBUTES           412   // DWORD
#define SPOT_PORT2GAINATTRIBUTES           413   // DWORD
#define SPOT_PORT3GAINATTRIBUTES           414   // DWORD
#define SPOT_READOUTCIRCUITDESCR           415   // NULL-terminated description string
#define SPOT_IMAGESENSORMODELDESCR         416   // NULL-terminated description string
#define SPOT_IMAGESENSORTYPE               417   // DWORD
#define SPOT_MINFASTSEQIMAGEEXPDUR         418   // DWORD (value in SPOT_EXPOSUREINCREMENT units)
#define SPOT_MAXNUMBERSKIPLINES            421   // short
#define SPOT_SENSORRESPONSEMODES           422   // array of DWORDs (1st val is count)
#define SPOT_SENSORCLEARMODES              423   // array of DWORDs (1st val is count)
#define SPOT_MINPIXELRESOLUTIONLEVEL       424   // short
#define SPOT_MAXNUMBERSEQIMAGEEXPDURS      425   // short
#define SPOT_PIXELRESOLUTIONIMGSIZEFACTORS 426   // array of floats (SPOT_MAXPIXELRESOLUTIONLEVEL-SPOT_MINPIXELRESOLUTIONLEVEL+1 elements)


// Flags for use with SpotGetCameraAttributes()
#define SPOT_ATTR_COLOR                    0x00000001  // camera can return color images
#define SPOT_ATTR_SLIDER                   0x00000002  // camera has a color filter slider
#define SPOT_ATTR_LIVEMODE                 0x00000004  // camera can run live mode
#define SPOT_ATTR_MOSAIC                   0x00000008  // camera has a Bayer pattern color mosaic CCD chip
#define SPOT_ATTR_EDGETRIGGER              0x00000010  // camera has an edge-type external trigger
#define SPOT_ATTR_BULBTRIGGER              0x00000020  // camera has a bulb-type external trigger
#define SPOT_ATTR_CLEARFILTER              0x00000040  // camera has a color filter with a clear state
#define SPOT_ATTR_1394                     0x00000080  // camera is an IEEE-1394/FireWire device
#define SPOT_ATTR_COLORFILTER              0x00000100  // camera has a color filter (color images require multiple shots)
#define SPOT_ATTR_TEMPERATUREREADOUT       0x00000200  // camera can read the sensor temperature
#define SPOT_ATTR_TEMPERATUREREGULATION    0x00000400  // camera can regulate the sensor temperature
#define SPOT_ATTR_TRIGGERACTIVESTATE       0x00000800  // camera can set trigger input active state
#define SPOT_ATTR_DUALAMPLIFIER            0x00001000  // camera has separate amplifier circuits for live mode and capture
#define SPOT_ATTR_ACCURATETTLDELAYTIMING   0x00002000  // camera can accurately time TTL output and trigger delays (to microseconds)
#define SPOT_ATTR_SLIDERPOSITIONDETECTION  0x00004000  // camera can detect the color filter slider position
#define SPOT_ATTR_AUTOEXPOSURE             0x00008000  // camera can compute exposure
#define SPOT_ATTR_TTLOUTPUT                0x00010000  // camera has a TTL output
#define SPOT_ATTR_SENSORSHIFTING           0x00020000  // camera can shift the position of the image sensor for higher resolution
#define SPOT_ATTR_FILTERWHEEL              0x00040000  // camera has a mechanical filter wheel
#define SPOT_ATTR_BLACKLEVELSUBTRACT       0x00080000  // camera can do black-level subtraction
#define SPOT_ATTR_CHIPDEFECTCORRECTION     0x00100000  // camera can do chip defect correction
#define SPOT_ATTR_INTERNALSHUTTER          0x00200000  // camera has an internal mechanical shutter
#define SPOT_ATTR_EXPOSURESHUTTER          0x00400000  // camera's internal shutter can be used for exposure
#define SPOT_ATTR_TTLOUTPUTDURINGEXPOSURE  0x00800000  // camera can activate TTL output during exposure
#define SPOT_ATTR_SINGLECHANLIVEMODE       0x01000000  // camera can use a single readout channel in live mode
#define SPOT_ATTR_MULTICHANLIVEMODE        0x02000000  // camera can use mutiple parallel readout channels in live mode
#define SPOT_ATTR_FIRMWAREUPDATE           0x04000000  // camera's firmware can be updated through the SpotCam API
#define SPOT_ATTR_LIVEHISTOGRAM            0x08000000  // camera can provide histogram information and do stretching in live mode


// Interface Types for use with SpotFindDevices()
#define SPOT_INTFTYPE_PCI           2    // PCI card
#define SPOT_INTFTYPE_1394          3    // 1394 (FireWire) camera
#define SPOT_INTFTYPE_USB           4    // USB camera


// Device Types for use with SpotFindDevices()
#define SPOT_DEVTYPE_RTCARD          3   // SPOT RT card
#define SPOT_DEVTYPE_RTINSIGHTCARD   SPOT_DEVTYPE_RTCARD
#define SPOT_DEVTYPE_INSIGHTCARD     4   // SPOT Insight card
#define SPOT_DEVTYPE_RTSE18CARD      6   // SPOT RT-SE18 card
#define SPOT_DEVTYPE_RT2CARD         7   // SPOT RT2 card
#define SPOT_DEVTYPE_BOOSTCARD       8   // SPOT Boost card
#define SPOT_DEVTYPE_1394CAMERA      32  // SPOT 1394 camera
#define SPOT_DEVTYPE_USBCAMERA       41  // SPOT USB camera


// Status Values
#define SPOT_STATUSIDLE                  0   // Doing nothing (operation completed)
                                             //  lInfo = return code
#define SPOT_STATUSDRVNOTINIT            1   // Driver not initialized
#define SPOT_STATUSEXPOSINGRED           2   // Exposing in Red -
                                             //  lInfo = exp time (in msec)
#define SPOT_STATUSEXPOSINGGREEN         3   // Exposing in Green -
                                             //  lInfo = exp time (in msec)
#define SPOT_STATUSEXPOSINGBLUE          4   // Exposing in Blue -
                                             //  lInfo = exp time (in msec)
#define SPOT_STATUSIMAGEREADRED          5   // Downloading Red image -
                                             //  lInfo = lines read
#define SPOT_STATUSIMAGEREADGREEN        6   // Downloading Green image -
                                             //  lInfo = lines read
#define SPOT_STATUSIMAGEREADBLUE         7   // Downloading Blue image -
                                             //  lInfo = lines read
#define SPOT_STATUSCOMPEXP               8   // Computing exposure
#define SPOT_STATUSCOMPWHITEBAL          9   // Computing white balance
#define SPOT_STATUSGETIMAGE              10  // Getting an image
                                             //  lInfo = number of exposures to be done
#define SPOT_STATUSLIVEIMAGEREADY        11  // Live image is available in buffer
                                             //  lInfo = address of image data buffer
#define SPOT_STATUSEXPOSINGCLEAR         12  // Exposing in Clear -
                                             //  lInfo = exp time (in msec)
#define SPOT_STATUSEXPOSING              13  // Exposing (filter off or no filter) -
                                             //  lInfo = exp time (in msec)
#define SPOT_STATUSIMAGEREADCLEAR        14  // Downloading monchrome image (clear filter)
                                             //  lInfo = lines read
#define SPOT_STATUSIMAGEREAD             15  // Downloading monchrome image (no filter)
                                             //  lInfo = lines read
#define SPOT_STATUSSEQIMAGEWAITING       16  // Waiting to acquire the next sequential image
                                             //  lInfo = msec until next image
#define SPOT_STATUSSEQIMAGEREADY         17  // A sequential image is available for
                                             // the application to retrieve
#define SPOT_STATUSIMAGEPROCESSING       18  // Processing an acquired image
                                             //  lInfo = index of image being processed
#define SPOT_STATUSWAITINGFORTRIGGER     19  // Waiting for a trigger
#define SPOT_STATUSWAITINGFORBLOCKLIGHT  20  // The user should block all light to the camera
#define SPOT_STATUSWAITINGFORMOVETOBKGD  21  // The user should move the specimen out of the path
#define SPOT_STATUSTTLOUTPUTDELAY        22  // Waiting for the specified TTL output delay to elapse
                                             //  lInfo = total delay in microseconds
#define SPOT_STATUSEXTERNALTRIGGERDELAY  23  // Waiting for the specified extrenal trigger delay to elapse
                                             //  lInfo = total delay in microseconds
#define SPOT_STATUSWAITINGFORCOLORFILTER 24  // Waiting for the color filter to change
#define SPOT_STATUSGETLIVEIMAGES         25  // Starting live image acquisition mode
#define SPOT_STATUSFANDELAY              26  // Waiting for specified delay after changing fan speed 
                                             //  lInfo = total delay in milliseconds
#define SPOT_STATUSFIRMWAREUPDATING      27  // Updating firmware for a device
                                             //  lInfo = pointer to SPOT_MESSAGE_STRUCT

#define SPOT_STATUSRUNNING               500 // The process is running (only applicable when SPOT_WAITFORSTATUSCHANGES is TRUE)
#define SPOT_STATUSABORTED               100 // Last operation was aborted
                                             //  lInfo = SPOT_ABORT
#define SPOT_STATUSERROR                 101 // Last operation ended in an error -
                                             //  lInfo = error code

// Device Notification Event Types
#define SPOT_DEVEVENTTYPE_DEVADDED        1  // A new device has been added - lInfo = 0
#define SPOT_DEVEVENTTYPE_DEVREMOVED      2  // A device has been removed - lInfo = 0


#if defined(macintosh)
   #pragma options align=power
#else
   #pragma pack(push)
   #pragma pack(1)
#endif

typedef struct
{
   union
   {
      long lExpMSec;
      long lClearExpMSec;  // NOTE: Use SPOT_EXPOSURE_STRUCT2 instead if
      long lRedExpMSec;    //       sub-millisecond resolution is required
   };
   long  lGreenExpMSec;
   long  lBlueExpMSec;
   short nGain;
} SPOT_EXPOSURE_STRUCT;


typedef struct
{
   DWORD dwRedExpDur;       // NOTE: Exposure durations are expressed in
   DWORD dwGreenExpDur;     //       in units defined by SPOT_EXPOSUREINCREMENT
   DWORD dwBlueExpDur;      //       The default is half-microseconds (500 ns)
   union
   {
      DWORD dwClearExpDur;
      DWORD dwExpDur;
   };
   short nGain;
} SPOT_EXPOSURE_STRUCT2;


typedef struct
{
   BOOL bEnableRed;         // NOTE: To enable the clear filter, use
   BOOL bEnableGreen;       //       SPOT_COLOR_ENABLE_STRUCT2 instead
   BOOL bEnableBlue;
} SPOT_COLOR_ENABLE_STRUCT;


typedef struct
{
   BOOL bEnableRed;
   BOOL bEnableGreen;
   BOOL bEnableBlue;
   BOOL bEnableClear;
} SPOT_COLOR_ENABLE_STRUCT2;


typedef struct
{
   short nReserved;  // Set this to zero!
   float fRedVal;
   float fGreenVal;
   float fBlueVal;
} SPOT_WHITE_BAL_STRUCT;


typedef struct
{
   long lRedVal;
   long lGreenVal;
   long lBlueVal;
} SPOT_WHITE_BAL_INT_STRUCT;



typedef struct
{
   char szProductName[255];
   char szCopyright[255];
   WORD wVerMajor;   // Driver version
   WORD wVerMinor;
   WORD wVerUpdate;
   char szCameraSerialNum[31];
} SPOT_VERSION_STRUCT;  // Obsolete


typedef struct
{
   char szProductName[255];
   char szCopyright[101];
   char szCameraFirmwareRevNum[11];
   char szCardHardwareRevNum[11];
   char szCardFirmwareRevNum[11];
   char Reserved[119];
   WORD wVerBugFix;
   WORD wVerMajor;  // Driver version
   WORD wVerMinor;
   WORD wVerUpdate;
   BYTE byReserved;
   char szCameraSerialNum[21];
   char szCameraModelNum[11];
   union
   {
      char szCameraRevNum[11];
      char szCameraHardwareRevNum[11];
   };
} SPOT_VERSION_STRUCT2;


typedef struct
{
#ifdef macintosh
   unsigned int macPCIDeviceID;
#else
   DWORD dwBus;
   DWORD dwSlot;
   DWORD dwFunction;
#endif
} SPOT_PCI_CARD_STRUCT;


typedef struct
{
   int n1394NodeNumber;
   int n1394BusNumber;
   BYTE Reserved[12];
} SPOT_1394_CAMERA_STRUCT;


typedef union
{
   struct
   {
      DWORD dwLowPart;
      DWORD dwHighPart;
#ifdef __cplusplus
   };
#else
   } d;
#endif // __cplusplus
   QWORD qwQuadPart;
} SPOT_DEVICE_UID;


typedef struct
{
   int nDeviceType;
   int nInterfaceType;
   union
   {
      SPOT_PCI_CARD_STRUCT stPCICard;
      SPOT_1394_CAMERA_STRUCT st1394Camera;
      BYTE Reserved[28];
   };
   DWORD dwAttributes;         // Attribute bit-flags
   char szDescription[54];
   SPOT_DEVICE_UID DeviceUID;  // Unique for every camera
} SPOT_DEVICE_STRUCT;


typedef struct
{
   WORD wYear;   // Calendar year (eg. 2004)
   WORD wMonth;  // Zero-based month (0=Jan, 11=Dec)
   WORD wDay;    // Day of month (1-31)
   WORD wHour;
   WORD wMinute;
   WORD wSecond;
   DWORD dwMicrosecond;
} SPOT_TIMESTAMP_STRUCT;


typedef struct
{
   char szCameraSerialNum[21];
   int  nBitDepth;
   int  nBinSize;
   SPOT_RECT stImageRect;
   int  anGains[50];
   int  nReadoutCircuit;
   int  nGainPort;
   float fPreAmpGain;
   int  nTemperature;
   int  nPixelResolutionLevel;
   BYTE Reserved[80];
} SPOT_BIAS_FRAME_COMPATIBILITY_INFO_STRUCT;


typedef struct
{
   char szCameraSerialNum[21];
   int  nBinSize;
   BOOL bHasRed, bHasGreen, bHasBlue, bHasClear;  // For cameras with color filters
   int  nPixelResolutionLevel;
   BYTE Reserved[100];
} SPOT_FLATFIELD_COMPATIBILITY_INFO_STRUCT;


typedef struct
{
   char szCameraSerialNum[21];
   int  nBitDepth;
   int  nBinSize;
   SPOT_RECT stImageRect;
   BOOL bHasRed, bHasGreen, bHasBlue, bHasClear;  // For cameras with color filters
   int  nPixelResolutionLevel;
   int  nReadoutCircuit;
   int  nGainPort;
   float fPreAmpGain;
   int  nTemperature;
   BYTE Reserved[84];
} SPOT_BKGD_IMAGE_COMPATIBILITY_INFO_STRUCT;


typedef struct
{
   union
   {
      int *pnPixelCounts;
      int *pnRedPixelCounts;
   };
   int *pnGreenPixelCounts;
   int *pnBluePixelCounts;
   SPOT_RECT stSampleRect;  // Area used for filling histogram
   BYTE Reserved[96];
} SPOT_LIVE_HISTOGRAM_STRUCT;


typedef struct
{
   BOOL  bAutoScale;
   float fBlackOverflowPct, fWhiteOverflowPct;  // Pcts of pixels at black and at white
   SPOT_RECT stSampleRect;  // Area used for filling histogram when auto-scaling
   int   nBlackPoint;       // May be negative
   int   nWhitePoint;
   int   nScale;            // nScale must be <= nWhitePoint 
   BYTE  Reserved[96];
} SPOT_LIVE_IMAGE_SCALING_STRUCT;


typedef struct
{
   int nMessageType; // One of the values defined for SPOT_MESSAGETYPE_XXX
   int nReserved;
   char szMessage[256];
   int nValue;
   BYTE Reserved[50];
} SPOT_MESSAGE_STRUCT;

#if defined(macintosh)
	#pragma options align=reset
#else
	#pragma pack(pop)
#endif


typedef VOID (WINAPI *SPOTCALLBACK)(int iStatus, long lInfo, DWORD dwUserData);
typedef VOID (WINAPI *SPOTDEVNOTIFYCALLBACK)(int iEventType, long lInfo, SPOT_DEVICE_UID *pDeviceUID, DWORD dwUserData);
typedef BOOL (WINAPI *SPOTBUSYCALLBACK)(DWORD dwUserData);  // Return true to abort operation


#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

int WINAPI SpotSetValue(short nParam, void *pValue);

int WINAPI SpotGetValue(short nParam, void *pValue);

int WINAPI SpotGetValueSize(short nParam);

int WINAPI SpotGetCameraAttributes(DWORD *pdwAttributes);

void WINAPI SpotGetVersionInfo(SPOT_VERSION_STRUCT *pstVerInfo);

void WINAPI SpotGetVersionInfo2(SPOT_VERSION_STRUCT2 *pstVerInfo);

int WINAPI SpotComputeExposure(SPOT_EXPOSURE_STRUCT *pstExposure);

int WINAPI SpotComputeExposure2(SPOT_EXPOSURE_STRUCT2 *pstExposure);

int WINAPI SpotComputeExposureConversionFactor(float *pfConvFactor);

int WINAPI SpotComputeExposureConversionFactorX1000(long *plConvFactor);

int WINAPI SpotComputeWhiteBalance(SPOT_WHITE_BAL_STRUCT *pstWhiteBal);

int WINAPI SpotComputeWhiteBalanceX1000(SPOT_WHITE_BAL_INT_STRUCT *pstWhiteBalInt);

int WINAPI SpotGetFlatfield(char *pszFileName);

int WINAPI SpotGetFlatfield2(char *pszFileName, int nNumFramesToAvg);

int WINAPI SpotGetBiasFrame(char *pszFileName, int nNumFramesToAvg);

int WINAPI SpotGetBackgroundImage(char *pszFileName, int nNumFramesToAvg);

int WINAPI SpotGetSensorCurrentTemperature(short *pnTemperature, BOOL *pbIsNewValue);

int WINAPI SpotGetSensorExposureTemperature(short *pnTemperature);

int WINAPI SpotGetExposureTimestamp(SPOT_TIMESTAMP_STRUCT *pstTimestamp);


#ifdef macintosh
int WINAPI SpotGetImage(short nReserved1, unsigned long lRowBytes, BOOL bReserved, short nReserved2,
                        void *pImageBuffer, long *plRedPixelCnts,
                        long *plGreenPixelCnts, long *plBluePixelCnts);

int WINAPI SpotGetSequentialImages(int nNumImages, int nIntervalMSec, BOOL bAutoExposeOnEach,
                                   BOOL bUseTriggerOrSetTTLOuputOnEach, BOOL bDeferProcessing,
                                   void **ppImageBuffers, unsigned long lRowBytes);

int WINAPI SpotRetrieveSequentialImage(void *pImageBuffer, unsigned long lRowBytes);

int WINAPI SpotGetLiveImages(BOOL bComputeExposure, short nFilterColor,
                             short nRotateDirection,
                             BOOL bFlipHoriz, BOOL bFlipVert,
                             void *pImageBuffer, unsigned long lRowBytes);

void WINAPI SpotSetMacCallback(SPOTCALLBACK pfnCB, DWORD dwUserData);
#else // _Windows
int WINAPI SpotGetImage(short nReserved1, BOOL bReserved, short nReserved2, void *pImageBuffer,
                        long *plRedPixelCnts, long *plGreenPixelCnts, long *plBluePixelCnts);

int WINAPI SpotGetSequentialImages(int nNumImages, int nIntervalMSec, BOOL bAutoExposeOnEach,
                                   BOOL bUseTriggerOrSetTTLOuputOnEach, BOOL bDeferProcessing,
                                   void **ppImageBuffers);

int WINAPI SpotRetrieveSequentialImage(void *pImageBuffer);

int WINAPI SpotGetLiveImages(BOOL bComputeExposure, short nFilterColor, short nRotateDirection,
                             BOOL bFlipHoriz, BOOL bFlipVert, void *pImageBuffer);
#endif

void WINAPI SpotSetAbortFlag(BOOL *pbAbort);

void WINAPI SpotSetCallback(SPOTCALLBACK pfnCallback, DWORD dwUserData);

void WINAPI SpotSetDeviceNotificationCallback(SPOTDEVNOTIFYCALLBACK pfnCallback, DWORD dwUserData);

void WINAPI SpotSetBusyCallback(SPOTBUSYCALLBACK pfnCallback, DWORD dwUserData);

int WINAPI SpotQueryStatus(BOOL bAbort, long *plInfo);

void WINAPI SpotClearStatus(void);

int WINAPI SpotQueryColorFilterPosition(BOOL *pbFilterIn, BOOL *pbFilterOut);

int WINAPI SpotQueryCameraPresent(BOOL *pbCameraPresent);

int WINAPI SpotSetTTLOutputState(BOOL bSetActive);

int WINAPI SpotInit(void);

int WINAPI SpotExit(void);

int WINAPI SpotDumpCameraMemory(char *pszFileName);

int WINAPI SpotFindDevices(SPOT_DEVICE_STRUCT *pstDevices, int *pnNumDevices);

int WINAPI SpotGetActualGainValue(int nGainPort, int nGain, float *pfActualGainValue);

int WINAPI SpotGetActualGainValueX10000(int nGainPort, int nGain, int *pnActualGainValue);

int WINAPI SpotGetActualLiveGainValue(int nGainPort, int nGain, float *pfActualGainValue);

int WINAPI SpotGetActualLiveGainValueX10000(int nGainPort, int nGain, int *pnActualGainValue);

int WINAPI SpotGetBiasFrameCompatibilityInformation(char *pszFileName, SPOT_BIAS_FRAME_COMPATIBILITY_INFO_STRUCT *pstInfo);

int WINAPI SpotGetFlatfieldCompatibilityInformation(char *pszFileName, SPOT_FLATFIELD_COMPATIBILITY_INFO_STRUCT *pstInfo);

int WINAPI SpotGetBackgroundImageCompatibilityInformation(char *pszFileName, SPOT_BKGD_IMAGE_COMPATIBILITY_INFO_STRUCT *pstInfo);

BOOL WINAPI SpotWaitForStatusChange(int *pnStatus, long *plInfo, int nTimeoutMSec);  // only applicable when SPOT_WAITFORSTATUSCHANGES is TRUE

int WINAPI SpotGetCameraErrorCode(void);

int WINAPI SpotUpdateFirmware(char *pszFWPkgFileName, DWORD dwControlFlags, DWORD *pdwResultFlags);
#ifdef __cplusplus
}
#endif // __cplusplus


// Old #defines included for backward-compatibility
#define SPOT_DEVTYPE_INSIGHT1394           SPOT_DEVTYPE_1394CAMERA 
#define SPOT_ERRNOINTFCARDSFOUND           SPOT_ERRNODEVICESFOUND
#define SPOT_EXPOSUREADJ                   SPOT_BRIGHTNESSADJ
#define SPOT_EXPOSUREADJX1000              SPOT_BRIGHTNESSADJX1000
#define SPOT_EXPOSUREADJLIMITS             SPOT_BRIGHTNESSADJLIMITS
#define SPOT_EXPOSUREADJLIMITSX1000        SPOT_BRIGHTNESSADJLIMITSX1000
#define SPOT_LIVEGAINADJ                   SPOT_LIVEBRIGHTNESSADJ
#define SPOT_LIVEGAINADJX1000              SPOT_LIVEBRIGHTNESSADJX1000
#define SPOT_EXTERNALSHUTTERENABLE         SPOT_ENABLETTLOUTPUT
#define SPOT_GAINVALS                      SPOT_GAINVALS8
#define SPOT_FLUORESCENCECOLORS            117   // No longer supported
#define SPOT_EXTERNALSHUTTERLAG            SPOT_TTLOUTPUTDELAYMS
#define SPOT_STATUSSHUTTEROPENRED          SPOT_STATUSEXPOSINGRED
#define SPOT_STATUSSHUTTEROPENGREEN        SPOT_STATUSEXPOSINGGREEN
#define SPOT_STATUSSHUTTEROPENBLUE         SPOT_STATUSEXPOSINGBLUE
#define SPOT_STATUSSHUTTEROPENCLEAR        SPOT_STATUSEXPOSINGCLEAR
#define SPOT_STATUSSHUTTEROPEN             SPOT_STATUSEXPOSING
#define SPOT_GAINVALS12                    SPOT_GAINVALS16
#define SPOT_PORT0GAINVALS12               SPOT_PORT0GAINVALS16
#define SPOT_CLEARMODECAMDEFAULT           0
#define SPOT_ERRVXDOPEN                    111 // no longer supported
#define SPOT_ERRWINRTLOAD                  112 // no longer supported
#define SPOT_ERRWINRTUNLOAD                113 // no longer supported
#define SPOT_ERRNOCAMERAINFOFILE           116 // no longer supported
#define SPOT_CLEARMODE                     SPOT_SENSORCLEARMODE
#define SPOT_CLEARMODES                    402
#define SPOT_CLEARMODEALWAYSAFTERREAD      SPOT_SENSORCLEARMODE_CONTINUOUS
#define SPOT_CLEARMODEPREEMPTABLE          SPOT_SENSORCLEARMODE_PREEMPTABLE

#endif // _SpotCamH_

