
#define CM_ABOUT           101
#define CM_CAMERA          102
#define CM_FIRSTCAMERA     200
#define CM_ACQSINGLEIMAGE  103
#define CM_ACQSEQIMAGES    104
#define CM_ACQSEQIMAGES2   105
#define CM_ACQLIVEIMAGES   106
#define CM_GETWHITEBAL     107
#define CM_READTEMPERATURE 108
#define CM_ABORT           198
#define CM_EXIT            199


#define IDC_STATUS         101
