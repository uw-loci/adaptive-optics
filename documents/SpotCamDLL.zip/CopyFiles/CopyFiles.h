


// Globals
//////////////////////////////

// Defines
//////////////////////////////


// Structures
//////////////////////////////

// Classes
/////////////////////////////



// Functions
/////////////////////////////

// SpotDrvr Callback function.
void WINAPI GetStatus(SpotDrvrStatus CurrentStatus, void *pExtraData, DWORD dwUserData);

// Displays help message.
void DisplayHelp();