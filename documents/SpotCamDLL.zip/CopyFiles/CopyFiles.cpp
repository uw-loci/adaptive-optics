// CopyFiles.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "CopyFiles.h"
#include "resource.h"

//-----------------------------------------------------------------------------------------------------

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                     LPSTR lpCmdLine, int nCmdShow)
{
	bool							bCanRestart = true;
	bool							bUseUIInterface = true;
	bool							bNeedToRestart = false;
	bool							bDisplayHelp = false;
	CString						cLogFile = "Installer Log.log";
	CString						cUserMessage;
	CString						cQuestion;
	CString						cError;
	CString						cAlert;
	CString						cInfo;
	int							ix;
	SpotDrvrError				InstallErrorCode;
	void							*pAnyThing = NULL; // Pointer to any object that can be passed to the callback.
	
	cAlert.LoadString(IDS_ALERT);
	cQuestion.LoadString(IDS_QUESTION);
	cError.LoadString(IDS_ERROR);
	cInfo.LoadString(IDS_INFO);

	cUserMessage.LoadString(IDS_START_MESSAGE);
	if(IDYES != MessageBox(0,(LPCTSTR)cUserMessage , (LPCTSTR)cQuestion, MB_ICONQUESTION|MB_YESNO))
		return 1;
	for(ix = 1; ix < __argc; ix++)
	{
		if(!strcmpi(__argv[ix], "/H") || !strcmpi(__argv[ix], "-H"))
		{
			DisplayHelp();
			return 0;
		}
		if(!strcmpi(__argv[ix], "/U") || !strcmpi(__argv[ix], "-U"))
			bUseUIInterface = false;
		if(!strcmpi(__argv[ix], "/R") || !strcmpi(__argv[ix], "-R"))
			bCanRestart = false;
		if(!strcmpi(__argv[ix], "/L") || !strcmpi(__argv[ix], "-L"))
			if(ix + 1 < __argc)
				cLogFile = __argv[++ix]; // Warning - Not checking to see if it is a valid path/file name.
	}
	// Set install log file name.
	SpotDrvrLogFile((char*)((LPCTSTR)cLogFile));

	// Set the callback function to receive status messages.
	SpotDrvrSetCallBack(GetStatus, (DWORD)pAnyThing); 

	// Boolean settings can be set either by sending the setting
	// and passing a NULL pointer to the second param pData.
	if(bUseUIInterface)  
		InstallErrorCode = SpotDrvrSetSetting(SD_SETTING_ALLOW_GUI);
	else
		InstallErrorCode = SpotDrvrSetSetting(SD_SETTING_NO_GUI);
	//Or by passing a bool* via pData to enable or disable the setting.
	InstallErrorCode = SpotDrvrSetSetting(SD_SETTING_ALLOW_RESTART, &bCanRestart);

	// After all settings are made start the installation.
	InstallErrorCode = SpotDrvrInstall(NULL);
	
	switch(InstallErrorCode)
	{
	case SD_ERROR_SUCCESS:
		cUserMessage.LoadString(IDS_FINNISHED);
		MessageBox(0, (LPCTSTR)cUserMessage, (LPCTSTR)cInfo, MB_OK);
		break;
	case SD_ERROR_NEED_TO_RESTART:
		cUserMessage.LoadString(IDS_NEED_TO_RESTART);
		MessageBox(0, (LPCTSTR)cUserMessage, (LPCTSTR)cAlert, MB_OK);
		break;
	default:
		cUserMessage.Format(IDS_UNKNOWN_ERROR, (DWORD)InstallErrorCode);
		MessageBox(0, (LPCTSTR)cUserMessage,(LPCTSTR) cError, MB_OK);
		return 1;
	}
	return 0;
}

//-----------------------------------------------------------------------------------------------------

void WINAPI GetStatus(SpotDrvrStatus CurrentStatus, void *pExtraData, DWORD dwUserData)
{
	CString			StatusMessage;
	CString			TextBuffer;


	switch(CurrentStatus)
	{
		// For SD_STATUS_XXX_DEVICE status messages
		// pExtraData may point to a CAMERA_INTERFACE_TYPE struct.
	case	SD_STATUS_LOCATING_DEVICE:
		StatusMessage.LoadString(IDS_LOCATING_DEV);
		if(pExtraData)
		{
			if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_PCI)
				TextBuffer.Format(" 0x%04X - 0x%04X", ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wVendor,
																				  ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wDevice);
			else if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_1394)
				TextBuffer = "1394";
			StatusMessage += TextBuffer;
		}
	break;
	case SD_STATUS_REMOVING_DEVICE:
		StatusMessage.LoadString(IDS_REMOVING_DEV);
		if(pExtraData)
		{
			if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_PCI)
				TextBuffer.Format(" 0x%04X - 0x%04X", ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wVendor,
																				  ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wDevice);
			else if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_1394)
				TextBuffer = "1394";
			StatusMessage += TextBuffer;
		}
		break;
	case	SD_STATUS_UPDATED_DEVICE:
		StatusMessage.LoadString(IDS_UPDATED_DEV);
		if(pExtraData)
		{
			if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_PCI)
				TextBuffer.Format(" 0x%04X - 0x%04X", ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wVendor,
																				  ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wDevice);
			else if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_1394)
				TextBuffer = "1394";
			StatusMessage += TextBuffer;
		}
		break;
	case SD_STATUS_UPDATING_REMOVED_DEVICE:
		StatusMessage.LoadString(IDS_UPDATING_DEV);
		if(pExtraData)
		{
			if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_PCI)
				TextBuffer.Format(" 0x%04X - 0x%04X", ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wVendor,
																				  ((CAMERA_INTERFACE_TYPE*)(pExtraData))->stPCIDevice.wDevice);
			else if(((CAMERA_INTERFACE_TYPE*)(pExtraData))->BusType == SD_BUS_1394)
				TextBuffer = "1394";
			StatusMessage += TextBuffer;
		}
		break;
	
	// For SD_STATUS_XXX_FILE status messages pExtraData may
	// point to a null terminated string of the full file name.
	case	SD_STATUS_INSTALLING_FILE:
		StatusMessage.Format(IDS_INSTALLING_FILE, pExtraData ? (char*)pExtraData : "");
		break;
	case	SD_STATUS_DELETING_FILE:
		StatusMessage.Format(IDS_DELETE_FILE, pExtraData ? (char*)pExtraData : "");
		break;

	// For SD_STATUS_XXX_DIRECTORY status messages pExtraData may
	// point to a null terminated string of the full path name.
	case SD_STATUS_CREATING_DIRECTORY:
		StatusMessage.Format(IDS_CREATE_DIR, pExtraData ? (char*)pExtraData : "");
		break;

	// For SD_STATUS_XXX_REGISTRY status messages pExtraData may
	// point to a null terminated string of the Registry key.
	case SD_STATUS_UPDATING_REGISTRY:
		StatusMessage.Format(IDS_UPDATING_REG, pExtraData ? (char*)pExtraData : "");
		break;

	case	SD_STATUS_STARTING_SERVICES:
		StatusMessage.LoadString(IDS_START_SERVICE);
		break;
	case SD_STATUS_STOPPING_SERVICES:
		StatusMessage.LoadString(IDS_STOP_SERVICE);
		break;
	case	SD_STATUS_RESTARTING:
		StatusMessage.LoadString(IDS_RESTARTING);
		break;
	default:
		StatusMessage.Format(IDS_UNKOWN, (DWORD)CurrentStatus);
		break;
	}
	// Do what you want with the message.
	//TextBuffer.LoadString(IDS_INFO);
	//MessageBox(0, (LPCTSTR)StatusMessage, (LPCTSTR)TextBuffer, MB_OK); 
}

//-----------------------------------------------------------------------------------------------------

void DisplayHelp()
{
	// No help message yet. 
}