
#if !defined(SPOTDRVR_H_INCLUDED_)
#define SPOTDRVR_H_INCLUDED_

#ifdef SPOTDRVR_EXPORTS  // Defined for DLL build only. Do not define!
#define SPOTDRVR_API 
#else
#define SPOTDRVR_API __declspec(dllimport)
#endif

// Parameter description text for function declarations.
#ifndef IN
	#define IN
#endif
#ifndef OUT
	#define OUT
#endif
#ifndef OPTIONAL
	#define OPTIONAL
#endif

#define MAX_FILE_PATH		260

//------------------------------------------------------------------------
//  Enumeration Types

// Error Return Codes
enum SpotDrvrError
{
	SD_ERROR_SUCCESS,
	SD_ERROR_CREATING_FILE,
	SD_ERROR_FILE_IS_NEWER,
	SD_ERROR_FILE_NOT_FOUND,
	SD_ERROR_FILE_CORRUPT,
	SD_ERROR_UNKNOWN,
	SD_ERROR_NEED_TO_RESTART,
	SD_ERROR_CREATING_DIRECTORY,
	SD_ERROR_OS_NOT_SUPPORTED,
	SD_ERROR_ABORTED,
	SD_ERROR_UNABLE_TO_ABORT,  //Depreciated - No longer vaild.
	SD_ERROR_SETTING_INVALID,
	SD_ERROR_INVALID_PARAMETER,
	SD_ERROR_NOT_ADMINISTRATOR,
	SD_ERROR_BUSY,
	SD_ERROR_WRITING_TO_REGISTRY
}; // SpotDrvrError

// Optional Settings
enum SpotDrvrSetting
{
	SD_SETTING_ALLOW_GUI =        0, 
	SD_SETTING_NO_GUI =           1,
	SD_SETTING_ALLOW_RESTART =    2, 
	SD_SETTING_NO_RESTART =       3,
   SD_SETTING_RESERVED =         4
}; // SpotDrvrSetting

// Callback Status Values
enum SpotDrvrStatus
{
	SD_STATUS_LOCATING_DEVICE,
	SD_STATUS_REMOVING_DEVICE,
	SD_STATUS_UPDATED_DEVICE,
	SD_STATUS_UPDATING_REMOVED_DEVICE,
	SD_STATUS_DELETING_FILE,
	SD_STATUS_INSTALLING_FILE,
	SD_STATUS_CREATING_DIRECTORY,
	SD_STATUS_STARTING_SERVICES,
	SD_STATUS_STOPPING_SERVICES,
	SD_STATUS_RESTARTING,
	SD_STATUS_UPDATING_REGISTRY
}; // SpotDrvrStatus

// Camera Hardware Bus Interface Types
enum SpotDrvrBusType
{
	SD_BUS_PCI,
	SD_BUS_1394
};


//------------------------------------------------------------------------
// Type Defines

#include <pshpack8.h>

typedef struct _DEVICE_PCI
{
	WORD		wVendor;
	WORD		wDevice;
	DWORD		dwSubSystem;
	BYTE		byRevison;
	DWORD		dwReserved;
} DEVICE_PCI, *PDEVICE_PCI;


typedef struct _DEVICE_1394
{
	DWORD    dwUnitSpecId;
   DWORD    dwUnitSwVersion;
   char     szDescription[488];
} DEVICE_1394, *PDEVICE_1394;


typedef struct _CAMERA_INTERFACE_TYPE  
{
	SpotDrvrBusType	BusType;
	void	*pReserved;
	union
	{
		DEVICE_PCI	stPCIDevice;
		DEVICE_1394	st1394Device;
	};
} CAMERA_INTERFACE_TYPE, *PCAMERA_INTERFACE_TYPE;

typedef struct _PRODUCT_INFO
{
   char  szManufacturerName[256];
   char  szProductName[256];
	SpotDrvrBusType	BusType;
	union
	{
		DEVICE_PCI	stPCIDevice;
		DEVICE_1394	st1394Device;
	};
} PRODUCT_INFO;

#include <poppack.h>

typedef void (WINAPI *SPOTDRVRCALLBACK)(SpotDrvrStatus CurrentStatus, void *pExtraData, DWORD dwUserData);

//------------------------------------------------------------------------
// API Functions
extern "C"
{
//<summary>Set options for installation.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrSetSetting(IN SpotDrvrSetting TheSetting, IN void* pData = NULL);
//<summary>Start the installation.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrInstall(void *pReserved = NULL);
//<summary>Abort the installation.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrAbort(IN bool bAbort);
//<summary>Return the last error code.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrGetLastError();
//<summary>Set the callback to receive status messages.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrSetCallBack(IN SPOTDRVRCALLBACK pfnCallback, IN DWORD dwUserData);
//<summary>Specify a file to log installation operations.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrLogFile(IN char* pszFilename);
//<summary>Useful function to determine if the currently logged in user is an administrator.</summary>
SPOTDRVR_API SpotDrvrError SpotDrvrIsAdministrator();
}


#endif //!defined(SPOTDRVR_H_INCLUDED_)