//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CopyFiles.rc
//
#define IDS_MISSING_FILE                1
#define IDS_NEWER_DRIVER                2
#define IDS_NEED_TO_RESTART             3
#define IDS_INFO                        5
#define IDS_ALERT                       6
#define IDS_ERROR                       7
#define IDS_WARNING                     8
#define IDS_START_MESSAGE               9
#define IDS_FINNISHED                   10
#define IDS_ERROR_CREATING_FILE         11
#define IDS_UNKNOWN_ERROR               12
#define IDS_FILE_CORRUPT                13
#define IDS_ERROR_CREATING_DIRECTORY    14
#define IDS_OS_NOTSUPPORTED             15
#define IDS_QUESTION                    16
#define IDS_LOCATING_DEV                17
#define IDS_UPDATED_DEV                 18
#define IDS_UPDATING_DEV                19
#define IDS_REMOVING_DEV                20
#define IDS_INSTALLING_FILE             21
#define IDS_DELETE_FILE                 22
#define IDS_CREATE_DIR                  23
#define IDS_START_SERVICE               24
#define IDS_UPDATING_REG                25
#define IDS_STOP_SERVICE                26
#define IDS_RESTARTING                  27
#define IDS_UNKOWN                      28
#define IDI_ICON1                       116

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        123
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
